
export type SessionType = '1-on-1' | 'Group' | 'Kids' | 'Seniors';

export interface Instructor {
  id: number;
  name: string;
  avatarUrl: string;
  bio: string;
  location: string;
  rating: number;
  reviewCount: number;
  languages: string[];
  specialties: string[];
  sessionTypes: SessionType[];
  pricing: {
    monthly: number;
    quarterly: number;
    yearly: number;
  };
  socialLinks: {
    twitter?: string;
    instagram?: string;
  }
  // Fields added to fix errors
  followers: number;
  students: number;
}

export interface Course {
  id: number;
  title: string;
  instructorId: number;
  language: string;
  description: string;
  imageUrl: string;
  level: 'Beginner' | 'Intermediate' | 'Advanced';
  duration: string; 
}

export interface Video {
  id: number;
  instructorId: number;
  type: 'reel' | 'short-video';
  title: string;
  thumbnailUrl: string;
  duration: string;
  views: number;
  likes: number;
  uploadedAt: string;
}

export interface InstructorPlatformPlan {
    id: number;
    name: string;
    price: number;
    frequency: string;
    description: string;
    features: string[];
    isPopular: boolean;
}

export interface StudentMembershipPlan {
    id: number;
    name: string;
    price: number;
    frequency: string;
    description: string;
    features: string[];
    isPopular: boolean;
}


// New types to fix errors
export interface Ad {
  imageUrl: string;
  title: string;
  description: string;
  link: string;
}

export interface Product {
  id: number;
  name: string;
  category: string;
  imageUrl: string;
  price: number;
  originalPrice?: number;
  rating: number;
  reviewCount: number;
  description: string;
}

export interface FilterState { // For Store page
  category: string;
  price: number;
  rating: number;
  search: string;
}

export type Level = 'All Levels' | 'Beginner' | 'Intermediate' | 'Advanced';

export interface LiveClass {
  id: number;
  title: string;
  instructorId: number;
  startTime: Date;
  durationMinutes: number;
  level: Level;
  isLive: boolean;
}

export interface SubscriptionPlan {
  id: number;
  name: string;
  price: number;
  frequency: string;
  description: string;
  features: string[];
  isPopular: boolean;
  type: 'unlimited' | 'pack';
}

export interface DailyContent {
    day: number;
    title: string;
    videoId: number;
    completed: boolean;
}

export interface Challenge {
  id: number;
  title: string;
  description: string;
  imageUrl: string;
  instructorId: number;
  level: Level;
  durationDays: number;
  participants: number;
  dailyContent: DailyContent[];
}

export interface Workshop {
  id: number;
  title: string;
  instructorId: number;
  imageUrl: string;
  level: Level;
  date: Date;
  durationHours: number;
  price: number;
  slots: number;
  slotsTaken: number;
}

export interface ForumCategory {
    id: number;
    name: string;
    description: string;
    threadCount: number;
    postCount: number;
}

export interface BookingSlot {
    id: number;
    instructorId: number;
    startTime: Date;
    isBooked: boolean;
}

// Types for the 6 new features

export interface UserStats {
    minutesPracticed: number;
    classesTaken: number;
    currentStreak: number;
}

export interface Badge {
    id: number;
    name: string;
    description: string;
    icon: React.ComponentType<React.SVGProps<SVGSVGElement>>;
}

export interface MusicTrack {
    id: number;
    title: string;
    artist: string;
    src: string; // URL to audio file
}

export interface InstructorAnalytics {
    revenue: { month: string; amount: number }[];
    revenueSource: { source: string; value: number }[];
    studentGrowth: { month: string; count: number }[];
    kpis: { name: string; value: string; change: number }[];
}

export interface CorporatePlan {
    id: number;
    name: string;
    price: string;
    description: string;
    features: string[];
}

export interface Retreat {
    id: number;
    title: string;
    location: string;
    instructorId: number;
    imageUrl: string;
    startDate: Date;
    endDate: Date;
    price: number;
    description: string;
}

export interface AdCampaign {
  id: number;
  name: string;
  adType: 'banner' | 'video' | 'instructor_promotion';
  status: 'active' | 'paused' | 'completed' | 'pending';
  impressions: number;
  clicks: number;
  conversions: number;
  budget: number;
  daily_spent: number;
  startDate: string;
  endDate: string;
}