
import React from 'react';
import { HashRouter, Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';

// All Pages
import Landing from './pages/Landing';
import Dashboard from './pages/Dashboard';
import InstructorDirectory from './pages/InstructorDirectory';
import InstructorDetail from './pages/InstructorDetail';
import Store from './pages/Store';
import ProductDetail from './pages/ProductDetail';
import LearningHub from './pages/Learn'; // Use Learn.tsx for courses
import Videos from './pages/Entertainment'; // Use Entertainment.tsx for videos
import Live from './pages/Live';
import Community from './pages/Community';
import ChallengeDetail from './pages/ChallengeDetail';
import Workshops from './pages/Workshops';
import Subscribe from './pages/Subscribe';
import Checkout from './pages/Checkout';
import ForInstructors from './pages/ForInstructors';
import NotFound from './pages/NotFound';

// 6 New Feature Pages
import Journey from './pages/Journey';
import Retreats from './pages/Retreats';
import Corporate from './pages/Corporate';
import AiAssistant from './pages/AiAssistant';
import Advertisements from './pages/Advertisements';

const App: React.FC = () => {
  return (
    <HashRouter>
      <div className="flex flex-col min-h-screen">
        <Header />
        <main className="flex-grow">
          <Routes>
            {/* The container and padding is handled by each page to allow for full-width sections */}
            <Route path="/" element={<Landing />} />
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/instructors" element={<InstructorDirectory />} />
            <Route path="/instructors/:instructorId" element={<InstructorDetail />} />
            <Route path="/store" element={<Store />} />
            <Route path="/store/product/:productId" element={<ProductDetail />} />
            <Route path="/learn" element={<LearningHub />} />
            <Route path="/videos" element={<Videos />} />
            <Route path="/live" element={<Live />} />
            <Route path="/community" element={<Community />} />
            <Route path="/challenges/:challengeId" element={<ChallengeDetail />} />
            <Route path="/workshops" element={<Workshops />} />
            <Route path="/subscribe" element={<Subscribe />} />
            <Route path="/checkout/:planId" element={<Checkout />} />
            <Route path="/checkout/instructor/:planId" element={<Checkout />} />
            <Route path="/for-instructors" element={<ForInstructors />} />
            
            {/* 6 New Routes */}
            <Route path="/journey" element={<Journey />} />
            <Route path="/retreats" element={<Retreats />} />
            <Route path="/corporate-wellness" element={<Corporate />} />
            <Route path="/ai-assistant" element={<AiAssistant />} />
            <Route path="/advertise" element={<Advertisements />} />
            
            <Route path="*" element={<NotFound />} />
          </Routes>
        </main>
        <Footer />
      </div>
    </HashRouter>
  );
};

export default App;
