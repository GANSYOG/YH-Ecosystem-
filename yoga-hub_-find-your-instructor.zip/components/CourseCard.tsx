
import React from 'react';
import { Link } from 'react-router-dom';
import { Course, Instructor } from '../types';

interface CourseCardProps {
  course: Course;
  instructor: Instructor;
}

const CourseCard: React.FC<CourseCardProps> = ({ course, instructor }) => {
  const levelColor = {
    Beginner: 'bg-green-100 text-green-800',
    Intermediate: 'bg-yellow-100 text-yellow-800',
    Advanced: 'bg-red-100 text-red-800',
  };

  return (
    <div className="group bg-white rounded-lg shadow-md overflow-hidden hover:shadow-2xl transition-shadow duration-300 flex flex-col">
      <div className="relative">
        <img className="h-56 w-full object-cover group-hover:scale-105 transition-transform duration-300" src={course.imageUrl} alt={course.title} />
        <div className="absolute top-0 right-0 m-2">
          <span className={`inline-flex items-center px-3 py-0.5 rounded-full text-sm font-medium ${levelColor[course.level]}`}>
            {course.level}
          </span>
        </div>
      </div>
      <div className="p-6 flex-grow flex flex-col">
        <div className="flex-grow">
            <p className="text-sm font-medium text-emerald-600">{course.language} &bull; {course.duration}</p>
            <h3 className="mt-2 text-xl font-semibold text-slate-800 group-hover:text-emerald-700 transition-colors">{course.title}</h3>
            <p className="mt-2 text-slate-600 text-sm">
              by <Link to={`/instructors/${instructor.id}`} className="font-medium hover:text-emerald-600 transition-colors">{instructor.name}</Link>
            </p>
            <p className="mt-3 text-base text-slate-500 line-clamp-3">{course.description}</p>
        </div>
        <div className="mt-6">
          <a href="#" className="w-full text-center bg-emerald-600 text-white px-4 py-2 rounded-md text-sm font-semibold hover:bg-emerald-700 transition-transform duration-200 hover:scale-105 block">
            Enroll Now
          </a>
        </div>
      </div>
    </div>
  );
};

export default CourseCard;
