
import React from 'react';
import { Link } from 'react-router-dom';
import { Instructor } from '../types';
import StarIcon from './icons/StarIcon';

const InstructorCard: React.FC<{ instructor: Instructor }> = ({ instructor }) => {
  return (
    <Link to={`/instructors/${instructor.id}`} className="group relative flex flex-col bg-white border border-slate-200 rounded-lg overflow-hidden transition-all duration-300 hover:shadow-xl hover:-translate-y-1">
      <div className="aspect-w-1 aspect-h-1 w-full overflow-hidden">
        <img
          src={instructor.avatarUrl}
          alt={instructor.name}
          className="w-full h-full object-cover object-center"
        />
      </div>
      <div className="p-4 flex flex-col flex-grow">
        <h3 className="text-lg font-bold text-slate-800 group-hover:text-emerald-600 transition-colors">{instructor.name}</h3>
        <p className="text-sm text-slate-500">{instructor.location}</p>
        <p className="mt-2 text-sm text-slate-600 font-medium line-clamp-1">
            {instructor.specialties.join(' • ')}
        </p>

        <div className="mt-2 flex items-center">
            <div className="flex items-center">
                {[...Array(5)].map((_, i) => (
                    <StarIcon key={i} className={`h-4 w-4 ${i < Math.round(instructor.rating) ? 'text-amber-400' : 'text-slate-300'}`} />
                ))}
            </div>
            <span className="ml-2 text-xs text-slate-500">{instructor.rating.toFixed(1)} ({instructor.reviewCount} reviews)</span>
        </div>
        
        <div className="flex-grow"></div>
        
        <div className="mt-4 border-t border-slate-100 pt-4">
             <div className="flex flex-wrap gap-2">
                {instructor.languages.slice(0, 3).map(lang => (
                    <span key={lang} className="px-2 py-1 text-xs font-semibold text-emerald-800 bg-emerald-100 rounded-full">{lang}</span>
                ))}
             </div>
        </div>
      </div>
    </Link>
  );
};

export default InstructorCard;
