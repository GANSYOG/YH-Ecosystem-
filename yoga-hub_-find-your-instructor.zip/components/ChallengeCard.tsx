
import React from 'react';
import { Link } from 'react-router-dom';
import { Challenge, Instructor } from '../types';
import UsersIcon from './icons/UsersIcon';

interface ChallengeCardProps {
  challenge: Challenge;
  instructor: Instructor;
}

const ChallengeCard: React.FC<ChallengeCardProps> = ({ challenge, instructor }) => {
    const levelColor = {
        'All Levels': 'bg-blue-100 text-blue-800',
        'Beginner': 'bg-green-100 text-green-800',
        'Intermediate': 'bg-yellow-100 text-yellow-800',
        'Advanced': 'bg-red-100 text-red-800',
    };

  return (
    <Link to={`/challenges/${challenge.id}`} className="group bg-white rounded-lg shadow-md overflow-hidden hover:shadow-2xl transition-shadow duration-300 flex flex-col">
      <div className="relative">
        <img className="h-56 w-full object-cover group-hover:scale-105 transition-transform duration-300" src={challenge.imageUrl} alt={challenge.title} />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent"></div>
        <div className="absolute bottom-0 left-0 p-4">
             <span className={`inline-flex items-center px-3 py-0.5 rounded-full text-xs font-medium ${levelColor[challenge.level]}`}>
                {challenge.level}
            </span>
        </div>
      </div>
      <div className="p-6 flex-grow flex flex-col">
          <h3 className="text-xl font-semibold text-slate-800 group-hover:text-emerald-700 transition-colors">{challenge.title}</h3>
          <p className="mt-2 text-slate-600 text-sm">
            With <span className="font-medium">{instructor.name}</span>
          </p>
          <div className="flex-grow"></div>
          <div className="mt-4 flex items-center justify-between text-sm text-slate-500 border-t pt-4">
              <span>{challenge.durationDays} Days</span>
              <div className="flex items-center gap-1">
                  <UsersIcon className="w-4 h-4" />
                  <span>{challenge.participants.toLocaleString()}</span>
              </div>
          </div>
      </div>
    </Link>
  );
};

export default ChallengeCard;
