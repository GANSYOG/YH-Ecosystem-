
import React from 'react';
import { AdCampaign } from '../types';
import EyeIcon from './icons/EyeIcon';
import CursorClickIcon from './icons/CursorClickIcon';
import BullseyeIcon from './icons/BullseyeIcon';
import TrendingUpIcon from './icons/TrendingUpIcon';

interface AdCampaignCardProps {
  campaign: AdCampaign;
}

const Stat: React.FC<{ icon: React.ReactNode; label: string; value: string | number }> = ({ icon, label, value }) => (
    <div className="flex items-center gap-2 text-slate-600">
        <div className="flex-shrink-0 w-5 h-5">{icon}</div>
        <div>
            <p className="text-sm font-bold text-slate-800">{value}</p>
            <p className="text-xs text-slate-500">{label}</p>
        </div>
    </div>
);

const AdCampaignCard: React.FC<AdCampaignCardProps> = ({ campaign }) => {
    const statusConfig = {
        active: { text: 'Active', color: 'bg-green-100 text-green-800', dot: 'bg-green-500' },
        paused: { text: 'Paused', color: 'bg-yellow-100 text-yellow-800', dot: 'bg-yellow-500' },
        completed: { text: 'Completed', color: 'bg-blue-100 text-blue-800', dot: 'bg-blue-500' },
        pending: { text: 'Pending', color: 'bg-slate-100 text-slate-800', dot: 'bg-slate-500' },
    };
    
    const currentStatus = statusConfig[campaign.status];
    const spent = campaign.status === 'completed' ? campaign.budget : campaign.daily_spent * 30; // rough estimate
    const progress = (spent / campaign.budget) * 100;

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden transition-shadow hover:shadow-xl">
        <div className="p-6">
            <div className="flex justify-between items-start gap-4">
                <div>
                    <p className="text-xs font-semibold uppercase tracking-wider text-emerald-600">{campaign.adType.replace('_', ' ')}</p>
                    <h3 className="text-xl font-bold text-slate-900 mt-1">{campaign.name}</h3>
                </div>
                <div className={`flex items-center gap-2 px-3 py-1 text-xs font-semibold rounded-full ${currentStatus.color}`}>
                    <span className={`w-2 h-2 rounded-full ${currentStatus.dot}`}></span>
                    {currentStatus.text}
                </div>
            </div>

            <div className="mt-4 pt-4 border-t border-slate-100 grid grid-cols-2 sm:grid-cols-4 gap-4">
                <Stat icon={<EyeIcon />} label="Impressions" value={campaign.impressions.toLocaleString()} />
                <Stat icon={<CursorClickIcon />} label="Clicks" value={campaign.clicks.toLocaleString()} />
                <Stat icon={<BullseyeIcon />} label="Conversions" value={campaign.conversions.toLocaleString()} />
                <Stat icon={<TrendingUpIcon />} label="Click-Thru Rate" value={`${campaign.impressions > 0 ? ((campaign.clicks / campaign.impressions) * 100).toFixed(2) : 0}%`} />
            </div>

            <div className="mt-4">
                <div className="flex justify-between mb-1">
                    <span className="text-sm font-medium text-slate-700">Budget</span>
                    <span className="text-sm font-medium text-slate-700">₹{spent.toLocaleString()} / ₹{campaign.budget.toLocaleString()}</span>
                </div>
                <div className="w-full bg-slate-200 rounded-full h-2.5">
                    <div className="bg-emerald-500 h-2.5 rounded-full" style={{ width: `${progress}%` }}></div>
                </div>
            </div>
        </div>

        <div className="bg-slate-50 px-6 py-3 flex justify-end items-center gap-3">
            <button onClick={() => alert('Analytics view is not yet implemented.')} className="text-sm font-semibold text-slate-600 hover:text-emerald-600 transition-colors">View Analytics</button>
            <button onClick={() => alert('Edit functionality is not yet implemented.')} className="text-sm font-semibold text-white bg-emerald-600 hover:bg-emerald-700 px-4 py-1.5 rounded-md transition-all">Edit</button>
        </div>
    </div>
  );
};

export default AdCampaignCard;
