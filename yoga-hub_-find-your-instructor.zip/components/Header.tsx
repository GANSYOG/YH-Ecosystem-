
import React, { useState, useEffect } from 'react';
import { NavLink, Link, useLocation } from 'react-router-dom';
import Logo from './Logo';
import MenuIcon from './icons/MenuIcon';
import XIcon from './icons/XIcon';

const Header: React.FC = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const location = useLocation();

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  useEffect(() => {
    setIsMobileMenuOpen(false);
  }, [location]);

  const navLinkClasses = "block md:inline-block px-3 py-2 rounded-md text-base md:text-sm font-medium text-slate-600 hover:bg-emerald-50 hover:text-emerald-700 transition-colors";
  const activeNavLinkClasses = "bg-emerald-100 text-emerald-700";

  const navLinks = (
    <>
      <NavLink to="/instructors" className={({ isActive }) => `${navLinkClasses} ${isActive ? activeNavLinkClasses : ''}`}>Instructors</NavLink>
      <NavLink to="/learn" className={({ isActive }) => `${navLinkClasses} ${isActive ? activeNavLinkClasses : ''}`}>Learning Hub</NavLink>
      <NavLink to="/workshops" className={({ isActive }) => `${navLinkClasses} ${isActive ? activeNavLinkClasses : ''}`}>Workshops</NavLink>
      <NavLink to="/retreats" className={({ isActive }) => `${navLinkClasses} ${isActive ? activeNavLinkClasses : ''}`}>Retreats</NavLink>
      <NavLink to="/store" className={({ isActive }) => `${navLinkClasses} ${isActive ? activeNavLinkClasses : ''}`}>Store</NavLink>
      <NavLink to="/advertise" className={({ isActive }) => `${navLinkClasses} ${isActive ? activeNavLinkClasses : ''}`}>Advertise</NavLink>
      <NavLink to="/community" className={({ isActive }) => `${navLinkClasses} ${isActive ? activeNavLinkClasses : ''}`}>Community</NavLink>
      <NavLink to="/journey" className={({ isActive }) => `${navLinkClasses} ${isActive ? activeNavLinkClasses : ''}`}>My Journey</NavLink>
    </>
  );

  return (
    <header className="bg-white/80 backdrop-blur-md shadow-sm sticky top-0 z-40">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center">
            <Link to="/">
              <Logo />
            </Link>
          </div>
          <nav className="hidden md:flex items-center space-x-1 lg:space-x-2">
            {navLinks}
          </nav>
          <div className="flex items-center space-x-4">
            <Link to="/for-instructors" className="text-sm font-medium text-slate-600 hover:text-emerald-600 transition-colors hidden sm:block">
              For Instructors
            </Link>
            <Link to="/subscribe" className="bg-emerald-600 text-white px-4 py-2 rounded-md text-sm font-semibold hover:bg-emerald-700 transition-transform duration-200 hover:scale-105">
              Subscribe
            </Link>
            <div className="md:hidden">
              <button
                onClick={toggleMobileMenu}
                className="inline-flex items-center justify-center p-2 rounded-md text-slate-600 hover:text-emerald-700 hover:bg-emerald-100 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-emerald-500"
                aria-controls="mobile-menu"
                aria-expanded={isMobileMenuOpen}
              >
                <span className="sr-only">Open main menu</span>
                {isMobileMenuOpen ? <XIcon className="block h-6 w-6" /> : <MenuIcon className="block h-6 w-6" />}
              </button>
            </div>
          </div>
        </div>
      </div>
      {/* Mobile menu, show/hide based on menu state. */}
      {isMobileMenuOpen && (
        <div className="md:hidden" id="mobile-menu">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
            {navLinks}
             <div className="border-t border-slate-200 my-2"></div>
              <Link to="/for-instructors" className={`${navLinkClasses}`}>
                For Instructors
              </Link>
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;
