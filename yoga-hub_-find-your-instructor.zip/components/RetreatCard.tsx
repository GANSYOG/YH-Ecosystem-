
import React from 'react';
import { Link } from 'react-router-dom';
import { Retreat, Instructor } from '../types';
import GlobeAltIcon from './icons/GlobeAltIcon';
import CalendarIcon from './icons/CalendarIcon';

interface RetreatCardProps {
  retreat: Retreat;
  instructor: Instructor;
}

const RetreatCard: React.FC<RetreatCardProps> = ({ retreat, instructor }) => {
  const formatDateRange = (start: Date, end: Date) => {
    const startStr = start.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
    const endStr = end.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
    return `${startStr} - ${endStr}`;
  };

  return (
    <div className="group bg-white rounded-lg shadow-md overflow-hidden hover:shadow-2xl transition-shadow duration-300 flex flex-col">
      <div className="relative">
        <img className="h-64 w-full object-cover group-hover:scale-105 transition-transform duration-300" src={retreat.imageUrl} alt={retreat.title} />
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent"></div>
        <div className="absolute bottom-0 left-0 p-4 text-white">
          <h3 className="text-2xl font-bold">{retreat.title}</h3>
          <div className="flex items-center gap-2 mt-1">
            <GlobeAltIcon className="w-5 h-5" />
            <p className="font-semibold">{retreat.location}</p>
          </div>
        </div>
        <div className="absolute top-0 right-0 m-3 bg-slate-900/60 text-white px-3 py-1.5 rounded-full text-lg font-bold backdrop-blur-sm">
          ₹{retreat.price.toLocaleString()}
        </div>
      </div>
      <div className="p-6 flex-grow flex flex-col">
        <p className="text-slate-600 line-clamp-3 flex-grow">{retreat.description}</p>
        <div className="mt-4 border-t pt-4 space-y-3">
          <div className="flex items-center gap-3 text-sm text-slate-700">
            <CalendarIcon className="w-5 h-5 text-emerald-600" />
            <span>{formatDateRange(retreat.startDate, retreat.endDate)}</span>
          </div>
          <div className="flex items-center gap-3 text-sm text-slate-700">
            <img src={instructor.avatarUrl} alt={instructor.name} className="w-8 h-8 rounded-full" />
            <span>With <Link to={`/instructors/${instructor.id}`} className="font-semibold hover:text-emerald-600">{instructor.name}</Link></span>
          </div>
        </div>
        <div className="mt-6">
          <Link to={`/retreats/${retreat.id}`} className="w-full text-center bg-emerald-600 text-white px-4 py-3 rounded-md font-semibold hover:bg-emerald-700 transition-transform duration-200 hover:scale-105 block">
            Learn More
          </Link>
        </div>
      </div>
    </div>
  );
};

export default RetreatCard;
