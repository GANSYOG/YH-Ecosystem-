
import React from 'react';
import { Link } from 'react-router-dom';
import { LiveClass, Instructor } from '../types';

interface LiveClassCardProps {
  liveClass: LiveClass;
  instructor: Instructor;
}

const formatTime = (date: Date) => {
  return date.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true });
};

const LiveClassCard: React.FC<LiveClassCardProps> = ({ liveClass, instructor }) => {
  const levelColor = {
    'All Levels': 'bg-blue-100 text-blue-800',
    'Beginner': 'bg-green-100 text-green-800',
    'Intermediate': 'bg-yellow-100 text-yellow-800',
    'Advanced': 'bg-red-100 text-red-800',
  };
  
  return (
    <div className="bg-white p-4 rounded-lg shadow-md flex items-center space-x-4 transition-shadow hover:shadow-lg">
      <div className="w-20 text-center flex-shrink-0">
        <p className="text-lg font-bold text-emerald-600">{formatTime(liveClass.startTime)}</p>
        <p className="text-sm text-slate-500">{liveClass.durationMinutes} min</p>
      </div>
      <div className="flex-1 border-l border-slate-200 pl-4">
        <div className="flex justify-between items-start">
            <div>
                <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${levelColor[liveClass.level]}`}>
                    {liveClass.level}
                </span>
                <h3 className="mt-1 text-lg font-semibold text-slate-800">{liveClass.title}</h3>
                <Link to={`/instructors/${instructor.id}`} className="text-sm text-slate-500 hover:text-emerald-600 flex items-center gap-2 mt-1">
                    <img src={instructor.avatarUrl} alt={instructor.name} className="w-6 h-6 rounded-full" />
                    <span>{instructor.name}</span>
                </Link>
            </div>
            {liveClass.isLive && (
                <span className="relative flex h-3 w-3">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-3 w-3 bg-red-500"></span>
                </span>
            )}
        </div>
      </div>
      <div className="flex-shrink-0">
        <button className={`px-4 py-2 rounded-md font-semibold text-sm transition-transform duration-200 hover:scale-105 ${
            liveClass.isLive 
            ? 'bg-red-600 text-white shadow-lg shadow-red-500/50' 
            : 'bg-emerald-600 text-white'
        }`}>
          {liveClass.isLive ? 'Join Now' : 'Book'}
        </button>
      </div>
    </div>
  );
};

export default LiveClassCard;