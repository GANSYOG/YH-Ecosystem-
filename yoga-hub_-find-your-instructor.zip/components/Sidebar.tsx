
import React from 'react';
import StarIcon from './icons/StarIcon';
import ChevronDownIcon from './icons/ChevronDownIcon';
import { FilterState } from '../types';

interface SidebarProps {
  filters: FilterState;
  setFilters: React.Dispatch<React.SetStateAction<FilterState>>;
  categories: string[];
}

const FilterSection: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => {
  const [isOpen, setIsOpen] = React.useState(true);
  return (
    <div className="py-6 border-b border-slate-200">
      <h3 className="-my-3 flow-root">
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="flex w-full items-center justify-between bg-white py-3 text-sm text-slate-400 hover:text-slate-500"
        >
          <span className="font-medium text-slate-900">{title}</span>
          <span className="ml-6 flex items-center">
            <ChevronDownIcon className={`h-5 w-5 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
          </span>
        </button>
      </h3>
      {isOpen && <div className="pt-6">{children}</div>}
    </div>
  );
};


const Sidebar: React.FC<SidebarProps> = ({ filters, setFilters, categories }) => {
  
  const handleCategoryChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFilters(prev => ({ ...prev, category: e.target.value === prev.category ? 'All' : e.target.value }));
  };
  
  const handlePriceChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFilters(prev => ({ ...prev, price: Number(e.target.value) }));
  };

  const handleRatingChange = (rating: number) => {
    setFilters(prev => ({ ...prev, rating: prev.rating === rating ? 0 : rating }));
  };

  return (
    <aside className="lg:col-span-1">
      <h2 className="sr-only">Filters</h2>

      <div className="hidden lg:block">
        <FilterSection title="Category">
          <div className="space-y-4">
            {categories.map((category) => (
              <div key={category} className="flex items-center">
                <input
                  id={`filter-category-${category}`}
                  name="category[]"
                  value={category}
                  type="radio"
                  checked={filters.category === category}
                  onChange={handleCategoryChange}
                  className="h-4 w-4 rounded border-gray-300 text-emerald-600 focus:ring-emerald-500"
                />
                <label htmlFor={`filter-category-${category}`} className="ml-3 text-sm text-gray-600">{category}</label>
              </div>
            ))}
          </div>
        </FilterSection>

        <FilterSection title="Price">
          <div className="space-y-4">
            <input 
              type="range" 
              min="0" 
              max="150" 
              value={filters.price}
              onChange={handlePriceChange}
              className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer" 
            />
            <div className="flex justify-between text-sm text-gray-600">
              <span>₹0</span>
              <span>₹{filters.price === 150 ? '150+' : filters.price}</span>
            </div>
          </div>
        </FilterSection>

        <FilterSection title="Rating">
            <div className="space-y-2">
                {[4, 3, 2, 1].map(rating => (
                    <button key={rating} onClick={() => handleRatingChange(rating)} className={`w-full flex items-center p-2 rounded-md ${filters.rating === rating ? 'bg-emerald-100' : 'bg-transparent'}`}>
                        {[...Array(5)].map((_, i) => (
                            <StarIcon key={i} className={`h-5 w-5 ${i < rating ? 'text-amber-400' : 'text-slate-300'}`} />
                        ))}
                        <span className="ml-2 text-sm text-gray-600">& up</span>
                    </button>
                ))}
            </div>
        </FilterSection>
      </div>
    </aside>
  );
};

export default Sidebar;
