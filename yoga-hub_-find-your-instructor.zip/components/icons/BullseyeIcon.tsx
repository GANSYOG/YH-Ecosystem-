
import React from 'react';

interface BullseyeIconProps extends React.SVGProps<SVGSVGElement> {}

const BullseyeIcon: React.FC<BullseyeIconProps> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 21a9 9 0 100-18 9 9 0 000 18z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M15.91 15.91a4.5 4.5 0 10-6.364-6.364 4.5 4.5 0 006.364 6.364z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 12a3 3 0 100-6 3 3 0 000 6z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 12a.75.75 0 100-1.5.75.75 0 000 1.5z" />
  </svg>
);

export default BullseyeIcon;