
import React from 'react';

interface TrophyIconProps extends React.SVGProps<SVGSVGElement> {}

const TrophyIcon: React.FC<TrophyIconProps> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M16.5 18.75h-9a9.75 9.75 0 00-4.5 1.432 2.25 2.25 0 00-.868 3.118A2.25 2.25 0 004.5 24h15a2.25 2.25 0 002.118-2.698 2.25 2.25 0 00-.868-3.118 9.75 9.75 0 00-4.5-1.432zM12 9.75a3.75 3.75 0 013.75 3.75H8.25A3.75 3.75 0 0112 9.75zM12 3v2.25m0 0a3.75 3.75 0 00-3.75 3.75H12m0-3.75a3.75 3.75 0 013.75 3.75h-3.75M12 3.75a3.75 3.75 0 00-3.75 3.75m0 0h-1.5m1.5 0a3.75 3.75 0 013.75-3.75M12 3.75a3.75 3.75 0 013.75 3.75m0 0h1.5m-1.5 0a3.75 3.75 0 00-3.75 3.75" />
  </svg>
);

export default TrophyIcon;
