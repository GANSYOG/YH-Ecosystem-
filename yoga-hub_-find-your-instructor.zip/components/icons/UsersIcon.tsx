import React from 'react';

interface UsersIconProps extends React.SVGProps<SVGSVGElement> {}

const UsersIcon: React.FC<UsersIconProps> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M18 18.72a9.094 9.094 0 003.741-.479 3 3 0 00-4.682-2.72m-7.5-2.962A3.375 3.375 0 0112 15a3.375 3.375 0 01-3.375-3.375M9 11.25a3.375 3.375 0 00-3.375 3.375m0 0a3 3 0 00-3.741-.479 3 3 0 00-4.682 2.72m.992-11.19a3.375 3.375 0 013.375-3.375h1.5a3.375 3.375 0 013.375 3.375m-6.75 0a3.375 3.375 0 00-3.375 3.375M15 11.25a3.375 3.375 0 013.375 3.375m0 0a3 3 0 013.741-.479 3 3 0 014.682 2.72m-18-2.962A3.375 3.375 0 0012 15a3.375 3.375 0 003.375-3.375m-6.75 0a3.375 3.375 0 013.375-3.375h1.5a3.375 3.375 0 013.375 3.375" />
  </svg>
);

export default UsersIcon;