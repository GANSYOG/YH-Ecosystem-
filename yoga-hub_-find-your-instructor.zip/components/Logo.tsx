
import React from 'react';

const Logo: React.FC = () => (
  <div className="flex items-center" aria-label="Yoga Hub Logo">
    <svg width="170" height="42" viewBox="0 0 170 42" className="h-10 w-auto">
      <defs>
        <linearGradient id="sunburstGradient" x1="0.5" y1="0" x2="0.5" y2="1">
          <stop offset="0%" stopColor="#FBBF24" />
          <stop offset="100%" stopColor="#F97316" />
        </linearGradient>
      </defs>
      
      {/* Sunburst */}
      <g transform="translate(25, 21)">
        {Array.from({ length: 16 }).map((_, i) => (
          <path
            key={i}
            d="M0 -18 L2.5 -12 L-2.5 -12 Z"
            fill="url(#sunburstGradient)"
            transform={`rotate(${i * 22.5})`}
            style={{ transformOrigin: 'center' }}
          />
        ))}
      </g>
      
      {/* Yogi Silhouette */}
      <g transform="translate(0, 2)">
        <path d="M25.5,38.5 C25.5,38.5 25,37.5 24,37 C23,36.5 22,37 22,37 L18,33 C17.5,32.5 17.5,31.5 18,31 C18.5,30.5 19.5,30.5 20,31 L23,34 L23.5,33 C23.5,30 24,27 26.5,25 C29,23 32,23.5 33,26 C34,28.5 33.5,31.5 31,33.5 C30.5,34 30,34 30.5,34.5 L34,38 L34.5,37.5 C35,37 36,37 36.5,37.5 C37,38 37,39 36.5,39.5 L31.5,40 C31,40.5 30,40.5 29.5,40 L26,38.5 L25.5,38.5 Z M31.5,15 C31.5,15 32.5,15 33,16 C33.5,17 32.5,18 31.5,18 C30.5,18 29.5,17 30,16 C30.5,15 31.5,15 31.5,15 Z M33,25 C32,22 28,21 26,23 C24,25 24.5,29.5 26.5,31.5 C27,32 28,32 29,31.5 C31.5,29.5 33,27 33,25 Z M18,30 L10,30 C9.5,30 9,29.5 9,29 C9,28.5 9.5,28 10,28 L19,28 L19,22 C19,20 21,19 23,19 C25,19 27,20 27,22" fill="#334155" transform="scale(0.8) translate(-10, -18)" />
      </g>
      
      {/* Text */}
      <text x="52" y="29" fontFamily="Inter, sans-serif" fontSize="22" fontWeight="600" fill="#1e293b" letterSpacing="-0.5">
        Yoga Hub
      </text>
    </svg>
  </div>
);

export default Logo;
