
import React from 'react';
import { Link } from 'react-router-dom';
import Logo from './Logo';

const Footer: React.FC = () => {
  return (
    <footer className="bg-slate-100 border-t border-slate-200">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-8">
          <div className="col-span-2 lg:col-span-1">
             <Link to="/">
                <Logo />
             </Link>
             <p className="mt-4 text-slate-500 text-sm">The global marketplace for yoga, connecting students and instructors worldwide.</p>
          </div>
          <div>
            <h3 className="text-sm font-semibold text-slate-600 uppercase tracking-wider">For Students</h3>
            <ul className="mt-4 space-y-2">
              <li><Link to="/instructors" className="text-base text-slate-500 hover:text-slate-900">Find an Instructor</Link></li>
              <li><Link to="/subscribe" className="text-base text-slate-500 hover:text-slate-900">Membership</Link></li>
              <li><Link to="/journey" className="text-base text-slate-500 hover:text-slate-900">My Journey</Link></li>
               <li><Link to="/retreats" className="text-base text-slate-500 hover:text-slate-900">Retreats</Link></li>
            </ul>
          </div>
          <div>
            <h3 className="text-sm font-semibold text-slate-600 uppercase tracking-wider">For Instructors</h3>
            <ul className="mt-4 space-y-2">
              <li><Link to="/for-instructors" className="text-base text-slate-500 hover:text-slate-900">Teach on Yoga Hub</Link></li>
              <li><Link to="/advertise" className="text-base text-slate-500 hover:text-slate-900">Advertise</Link></li>
              <li><Link to="/ai-assistant" className="text-base text-slate-500 hover:text-slate-900">AI Assistant</Link></li>
              <li><a href="#" className="text-base text-slate-500 hover:text-slate-900">Resources</a></li>
            </ul>
          </div>
          <div className="col-span-2 md:col-span-1">
            <h3 className="text-sm font-semibold text-slate-600 uppercase tracking-wider">Company</h3>
            <ul className="mt-4 space-y-2">
              <li><a href="#" className="text-base text-slate-500 hover:text-slate-900">About</a></li>
              <li><a href="#" className="text-base text-slate-500 hover:text-slate-900">Blog</a></li>
              <li><Link to="/corporate-wellness" className="text-base text-slate-500 hover:text-slate-900">Corporate Wellness</Link></li>
              <li><a href="#" className="text-base text-slate-500 hover:text-slate-900">Contact</a></li>
            </ul>
          </div>
        </div>
        <div className="mt-12 border-t border-slate-200 pt-8 flex items-center justify-between">
            <p className="text-base text-slate-500">&copy; 2024 Yoga Hub, Inc. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;