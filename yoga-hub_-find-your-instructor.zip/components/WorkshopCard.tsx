
import React from 'react';
import { Link } from 'react-router-dom';
import { Workshop, Instructor } from '../types';
import ClockIcon from './ClockIcon';
import UsersIcon from './icons/UsersIcon';

interface WorkshopCardProps {
  workshop: Workshop;
  instructor: Instructor;
}

const WorkshopCard: React.FC<WorkshopCardProps> = ({ workshop, instructor }) => {
  const levelColor = {
    'All Levels': 'bg-blue-100 text-blue-800',
    'Beginner': 'bg-green-100 text-green-800',
    'Intermediate': 'bg-yellow-100 text-yellow-800',
    'Advanced': 'bg-red-100 text-red-800',
  };

  const slotsLeft = workshop.slots - workshop.slotsTaken;

  return (
    <div className="group bg-white rounded-lg shadow-md overflow-hidden hover:shadow-2xl transition-shadow duration-300 flex flex-col">
      <div className="relative">
        <img className="h-56 w-full object-cover group-hover:scale-105 transition-transform duration-300" src={workshop.imageUrl} alt={workshop.title} />
        <div className="absolute top-0 right-0 m-2">
          <span className={`inline-flex items-center px-3 py-0.5 rounded-full text-sm font-medium ${levelColor[workshop.level]}`}>
            {workshop.level}
          </span>
        </div>
         <div className="absolute top-0 left-0 m-2 bg-slate-900/50 text-white px-3 py-1 rounded-full text-sm font-semibold backdrop-blur-sm">
          ₹{workshop.price}
        </div>
      </div>
      <div className="p-6 flex-grow flex flex-col">
        <div className="flex-grow">
            <p className="text-sm font-medium text-emerald-600">{workshop.date.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</p>
            <h3 className="mt-2 text-xl font-semibold text-slate-800 group-hover:text-emerald-700 transition-colors">{workshop.title}</h3>
            <p className="mt-2 text-slate-600 text-sm">
              With <Link to={`/instructors/${instructor.id}`} className="font-medium hover:text-emerald-600 transition-colors">{instructor.name}</Link>
            </p>
            <div className="mt-3 flex items-center text-sm text-slate-500 gap-4">
                <div className="flex items-center gap-1.5">
                    <ClockIcon className="w-4 h-4" />
                    <span>{workshop.durationHours} hours</span>
                </div>
                 <div className="flex items-center gap-1.5">
                    <UsersIcon className="w-4 h-4" />
                    <span>{slotsLeft} spots left</span>
                </div>
            </div>
        </div>
        <div className="mt-6">
          {slotsLeft > 0 ? (
             <Link to="/subscribe" className="w-full text-center bg-emerald-600 text-white px-4 py-2 rounded-md text-sm font-semibold hover:bg-emerald-700 transition-transform duration-200 hover:scale-105 block">
                Book Now
             </Link>
          ) : (
            <button className="w-full text-center bg-slate-400 text-white px-4 py-2 rounded-md text-sm font-semibold cursor-not-allowed" disabled>
                Sold Out
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default WorkshopCard;
