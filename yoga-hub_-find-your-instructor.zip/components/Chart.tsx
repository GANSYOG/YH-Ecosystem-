
import React from 'react';

interface ChartProps {
  data: any[];
  type: 'bar' | 'pie';
  xKey: string;
  yKey: string;
}

// This is a mock chart component to simulate data visualization.
// In a real app, this would be replaced with a library like Recharts or Chart.js.
const Chart: React.FC<ChartProps> = ({ data, type, xKey, yKey }) => {
  if (type === 'bar') {
    const maxValue = Math.max(...data.map(d => d[yKey]));
    return (
      <div className="w-full h-64 flex items-end justify-around space-x-2 bg-slate-50 p-4 rounded-lg">
        {data.map((d, i) => (
          <div key={i} className="flex-1 flex flex-col items-center justify-end">
            <div 
              className="w-full bg-emerald-400 hover:bg-emerald-500 rounded-t-md transition-all"
              style={{ height: `${(d[yKey] / maxValue) * 100}%` }}
              title={`${d[xKey]}: ${d[yKey]}`}
            ></div>
            <p className="text-xs text-slate-500 mt-1">{d[xKey]}</p>
          </div>
        ))}
      </div>
    );
  }

  if (type === 'pie') {
    const totalValue = data.reduce((sum, d) => sum + d[yKey], 0);
    const colors = ['bg-emerald-500', 'bg-teal-500', 'bg-cyan-500', 'bg-sky-500'];
    return (
        <div className="w-full flex flex-col items-center justify-center">
            <div className="w-48 h-48 rounded-full flex items-center justify-center text-white font-bold text-lg" 
                 style={{background: `conic-gradient(from 0deg, #10b981 0% ${data[0].value}%, #14b8a6 ${data[0].value}% ${data[0].value + data[1].value}%, #06b6d4 ${data[0].value + data[1].value}% 100%)`}}>
            </div>
             <div className="mt-4 w-full space-y-2">
                {data.map((d, i) => (
                    <div key={i} className="flex items-center justify-between text-sm">
                        <div className="flex items-center gap-2">
                            <div className={`w-3 h-3 rounded-full ${colors[i % colors.length]}`}></div>
                            <p className="text-slate-600">{d[xKey]}</p>
                        </div>
                        <p className="font-semibold text-slate-800">{d[yKey]}%</p>
                    </div>
                ))}
            </div>
        </div>
    );
  }

  return null;
};

export default Chart;
