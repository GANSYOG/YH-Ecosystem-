
import React from 'react';
import { Ad } from '../types';

interface AdBannerProps {
  ad: Ad;
}

const AdBanner: React.FC<AdBannerProps> = ({ ad }) => {
  return (
    <div className="bg-gradient-to-r from-emerald-50 to-teal-50 rounded-lg shadow-md overflow-hidden my-8">
      <div className="flex flex-col md:flex-row items-center">
        <div className="md:w-1/3">
          <img src={ad.imageUrl} alt={ad.title} className="w-full h-48 md:h-full object-cover" />
        </div>
        <div className="p-6 md:w-2/3">
          <h3 className="text-sm font-semibold uppercase text-emerald-600 tracking-wider">Sponsored</h3>
          <h2 className="text-2xl font-bold text-slate-800 mt-1">{ad.title}</h2>
          <p className="text-slate-600 mt-2">{ad.description}</p>
          <a href={ad.link} className="inline-block mt-4 bg-emerald-600 text-white px-5 py-2 rounded-md text-sm font-semibold hover:bg-emerald-700 transition-transform duration-200 hover:scale-105">
            Learn More
          </a>
        </div>
      </div>
    </div>
  );
};

export default AdBanner;
