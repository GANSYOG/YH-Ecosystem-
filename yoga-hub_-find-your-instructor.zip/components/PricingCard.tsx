
import React from 'react';
import { Link } from 'react-router-dom';
import CheckIcon from './icons/CheckIcon';

interface Plan {
  id: number;
  name: string;
  price: number;
  frequency: string;
  description: string;
  features: string[];
  isPopular: boolean;
  ctaText: string;
}

interface PricingCardProps {
  plan: Plan;
  checkoutUrl: string;
}

const PricingCard: React.FC<PricingCardProps> = ({ plan, checkoutUrl }) => {
  return (
    <div className={`relative flex flex-col p-8 rounded-2xl bg-white shadow-lg transition-all duration-300 ${plan.isPopular ? 'border-2 border-emerald-500 scale-105' : 'border border-slate-200'}`}>
      {plan.isPopular && (
        <div className="absolute top-0 -translate-y-1/2 bg-emerald-500 text-white px-3 py-1 text-sm font-semibold rounded-full shadow-lg">
          Most Popular
        </div>
      )}
      <h3 className="text-2xl font-semibold leading-6 text-slate-900">{plan.name}</h3>
      <p className="mt-4 flex items-baseline gap-x-2">
        <span className="text-5xl font-bold tracking-tight text-slate-900">₹{plan.price}</span>
        <span className="text-base text-slate-500">{plan.frequency}</span>
      </p>
      <p className="mt-6 text-base leading-7 text-slate-600">{plan.description}</p>
      <ul role="list" className="mt-8 space-y-3 text-sm leading-6 text-slate-600 sm:mt-10 flex-grow">
        {plan.features.map((feature) => (
          <li key={feature} className="flex gap-x-3">
            <CheckIcon className="h-6 w-5 flex-none text-emerald-500" aria-hidden="true" />
            {feature}
          </li>
        ))}
      </ul>
      <Link
        to={checkoutUrl}
        className={`mt-8 block rounded-md px-3.5 py-2.5 text-center text-sm font-semibold transition-all duration-200
          ${plan.isPopular 
            ? 'bg-emerald-600 text-white shadow-md hover:bg-emerald-500 focus-visible:outline-emerald-600 hover:scale-105'
            : 'bg-white text-emerald-600 ring-1 ring-inset ring-emerald-200 hover:bg-emerald-50 focus-visible:outline-emerald-600'}`
        }
      >
        {plan.ctaText}
      </Link>
    </div>
  );
};

export default PricingCard;
