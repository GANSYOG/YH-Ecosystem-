
import React, { useState } from 'react';
import { MusicTrack } from '../types';
import PlayIcon from './icons/PlayIcon';
import MusicNoteIcon from './icons/MusicNoteIcon';

interface MusicPlayerProps {
  tracks: MusicTrack[];
}

const MusicPlayer: React.FC<MusicPlayerProps> = ({ tracks }) => {
  const [selectedTrack, setSelectedTrack] = useState<MusicTrack | null>(tracks[0] || null);
  const [isPlaying, setIsPlaying] = useState(false);

  return (
    <div className="bg-white p-4 rounded-lg shadow-md flex flex-col sm:flex-row items-center gap-4">
      <div className="flex items-center gap-3 flex-shrink-0">
        <div className="bg-emerald-100 p-2 rounded-full">
            <MusicNoteIcon className="h-6 w-6 text-emerald-600" />
        </div>
        <button onClick={() => setIsPlaying(!isPlaying)} className="bg-emerald-600 text-white rounded-full p-2 hover:bg-emerald-700 transition">
          <PlayIcon className={`w-5 h-5 transition-transform ${isPlaying ? 'scale-90' : ''}`} />
        </button>
        <div>
            <p className="font-semibold text-slate-800">{selectedTrack?.title || 'No Track'}</p>
            <p className="text-sm text-slate-500">{selectedTrack?.artist || 'Select a track'}</p>
        </div>
      </div>
      <div className="flex-grow w-full sm:w-auto">
        <div className="relative h-1 bg-slate-200 rounded-full w-full">
            <div className="absolute h-1 bg-emerald-500 rounded-full" style={{width: '30%'}}></div>
            <div className="absolute h-4 w-4 bg-white border-2 border-emerald-500 rounded-full -mt-1.5" style={{left: '30%'}}></div>
        </div>
      </div>
      <div className="flex-shrink-0">
        <select 
            value={selectedTrack?.id} 
            onChange={(e) => setSelectedTrack(tracks.find(t => t.id === Number(e.target.value)) || null)}
            className="bg-slate-100 border-slate-200 rounded-md p-2 text-sm font-medium text-slate-700 focus:ring-emerald-500 focus:border-emerald-500"
        >
          {tracks.map(track => (
            <option key={track.id} value={track.id}>{track.title}</option>
          ))}
        </select>
      </div>
    </div>
  );
};

export default MusicPlayer;
