
import React from 'react';
import ChevronDownIcon from './icons/ChevronDownIcon';
import { SessionType } from '../types';

interface FilterState {
    language: string;
    specialty: string;
    sessionType: string;
    search: string;
}

interface FilterProps {
    filters: FilterState;
    setFilters: React.Dispatch<React.SetStateAction<FilterState>>;
    languages: string[];
    specialties: string[];
    sessionTypes: (SessionType | 'All')[];
}

const FilterSection: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => {
  const [isOpen, setIsOpen] = React.useState(true);
  return (
    <div className="py-6 border-b border-slate-200">
      <h3 className="-my-3 flow-root">
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="flex w-full items-center justify-between bg-white py-3 text-sm text-slate-400 hover:text-slate-500"
        >
          <span className="font-medium text-slate-900">{title}</span>
          <span className="ml-6 flex items-center">
            <ChevronDownIcon className={`h-5 w-5 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
          </span>
        </button>
      </h3>
      {isOpen && <div className="pt-6 space-y-2">{children}</div>}
    </div>
  );
};

const Filters: React.FC<FilterProps> = ({ filters, setFilters, languages, specialties, sessionTypes }) => {
    
    const handleFilterChange = (filterType: keyof FilterState, value: string) => {
        setFilters(prev => ({...prev, [filterType]: value}));
    }

    return (
        <aside className="hidden lg:block lg:col-span-1">
            <h2 className="sr-only">Filters</h2>

            <FilterSection title="Languages">
                {languages.map(lang => (
                    <div key={lang} className="flex items-center">
                        <input id={`filter-lang-${lang}`} name="language" value={lang} type="radio" checked={filters.language === lang} onChange={() => handleFilterChange('language', lang)} className="h-4 w-4 rounded-full border-gray-300 text-emerald-600 focus:ring-emerald-500" />
                        <label htmlFor={`filter-lang-${lang}`} className="ml-3 text-sm text-gray-600">{lang}</label>
                    </div>
                ))}
            </FilterSection>

            <FilterSection title="Specialty">
                {specialties.map(spec => (
                    <div key={spec} className="flex items-center">
                        <input id={`filter-spec-${spec}`} name="specialty" value={spec} type="radio" checked={filters.specialty === spec} onChange={() => handleFilterChange('specialty', spec)} className="h-4 w-4 rounded-full border-gray-300 text-emerald-600 focus:ring-emerald-500" />
                        <label htmlFor={`filter-spec-${spec}`} className="ml-3 text-sm text-gray-600">{spec}</label>
                    </div>
                ))}
            </FilterSection>
            
            <FilterSection title="Session Type">
                {sessionTypes.map(type => (
                    <div key={type} className="flex items-center">
                        <input id={`filter-session-${type}`} name="sessionType" value={type} type="radio" checked={filters.sessionType === type} onChange={() => handleFilterChange('sessionType', type)} className="h-4 w-4 rounded-full border-gray-300 text-emerald-600 focus:ring-emerald-500" />
                        <label htmlFor={`filter-session-${type}`} className="ml-3 text-sm text-gray-600">{type}</label>
                    </div>
                ))}
            </FilterSection>
        </aside>
    );
};

export default Filters;
