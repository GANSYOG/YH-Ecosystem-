
import React from 'react';
import { Badge as BadgeType } from '../types';

interface BadgeProps {
  badge: BadgeType;
  unlocked: boolean;
}

const Badge: React.FC<BadgeProps> = ({ badge, unlocked }) => {
  const Icon = badge.icon;
  return (
    <div className={`text-center p-4 rounded-lg transition-all duration-300 ${unlocked ? 'bg-white shadow-md' : 'bg-slate-100'}`}>
      <div className={`mx-auto h-16 w-16 flex items-center justify-center rounded-full transition-colors ${unlocked ? 'bg-amber-100 text-amber-500' : 'bg-slate-200 text-slate-400'}`}>
        <Icon className="w-8 h-8" />
      </div>
      <h3 className={`mt-3 font-semibold ${unlocked ? 'text-slate-800' : 'text-slate-500'}`}>{badge.name}</h3>
      <p className={`text-xs mt-1 ${unlocked ? 'text-slate-500' : 'text-slate-400'}`}>{badge.description}</p>
    </div>
  );
};

export default Badge;
