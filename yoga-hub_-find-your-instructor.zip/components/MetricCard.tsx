
import React from 'react';

interface MetricCardProps {
  name: string;
  value: string;
  change: number;
}

const MetricCard: React.FC<MetricCardProps> = ({ name, value, change }) => {
  const isPositive = change >= 0;
  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <p className="text-sm font-medium text-slate-500">{name}</p>
      <div className="mt-1 flex items-baseline justify-between">
        <p className="text-2xl font-bold text-slate-800">{value}</p>
        <div className={`flex items-center text-sm font-semibold ${isPositive ? 'text-green-600' : 'text-red-600'}`}>
          {isPositive ? '▲' : '▼'}
          <span className="ml-1">{Math.abs(change)}%</span>
        </div>
      </div>
    </div>
  );
};

export default MetricCard;
