
import React from 'react';
import { Link } from 'react-router-dom';
import { Product } from '../types';
import StarIcon from './icons/StarIcon';
import ShoppingCartIcon from './icons/ShoppingCartIcon';
import HeartIcon from './icons/HeartIcon';

interface ProductCardProps {
  product: Product;
}

const Rating: React.FC<{ rating: number; reviewCount: number }> = ({ rating, reviewCount }) => (
    <div className="flex items-center">
        <div className="flex items-center">
            {[...Array(5)].map((_, i) => (
                <StarIcon key={i} className={`h-5 w-5 ${i < Math.round(rating) ? 'text-amber-400' : 'text-slate-300'}`} />
            ))}
        </div>
        <span className="ml-2 text-sm text-slate-500">({reviewCount})</span>
    </div>
);

const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    alert(`Added ${product.name} to cart!`);
  }

  const handleAddToWishlist = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    alert(`Added ${product.name} to wishlist!`);
  }

  return (
    <div className="group relative flex flex-col bg-white border border-slate-200 rounded-lg overflow-hidden transition-shadow hover:shadow-xl duration-300">
      <Link to={`/store/product/${product.id}`} className="flex flex-col flex-grow">
        <div className="aspect-w-1 aspect-h-1 w-full overflow-hidden">
          <img
            src={product.imageUrl}
            alt={product.name}
            className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-300"
          />
        </div>
        <div className="p-4 flex flex-col flex-grow">
          <h3 className="text-sm text-slate-500">{product.category}</h3>
          <h4 className="mt-1 text-lg font-semibold text-slate-800 hover:text-emerald-600 transition-colors">
              {product.name}
          </h4>
          <div className="mt-2">
              <Rating rating={product.rating} reviewCount={product.reviewCount} />
          </div>
          <div className="flex-grow"></div>
          <div className="flex items-baseline justify-between mt-4">
            <div>
              <span className="text-xl font-bold text-slate-900">₹{product.price}</span>
              {product.originalPrice && (
                <span className="ml-2 text-sm text-slate-500 line-through">₹{product.originalPrice}</span>
              )}
            </div>
          </div>
        </div>
      </Link>
       <div className="absolute top-2 right-2 flex flex-col space-y-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300 z-10">
          <button onClick={handleAddToWishlist} className="p-2 bg-white/70 backdrop-blur-sm rounded-full text-slate-600 hover:bg-emerald-500 hover:text-white transition-all">
              <HeartIcon className="h-5 w-5"/>
          </button>
           <button onClick={handleAddToCart} className="p-2 bg-white/70 backdrop-blur-sm rounded-full text-slate-600 hover:bg-emerald-500 hover:text-white transition-all">
              <ShoppingCartIcon className="h-5 w-5"/>
          </button>
      </div>
    </div>
  );
};

export default ProductCard;
