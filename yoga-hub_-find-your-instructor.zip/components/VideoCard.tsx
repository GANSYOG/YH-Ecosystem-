
import React from 'react';
import { Link } from 'react-router-dom';
import { Video, Instructor } from '../types';
import PlayIcon from './icons/PlayIcon';
import HeartIcon from './icons/HeartIcon';
import EyeIcon from './icons/EyeIcon';

interface VideoCardProps {
  video: Video;
  instructor: Instructor;
}

const formatViews = (views: number) => {
    if (views >= 1000) {
        return `${(views / 1000).toFixed(1)}k`;
    }
    return views;
}

const VideoCard: React.FC<VideoCardProps> = ({ video, instructor }) => {
  const isReel = video.type === 'reel';
  const containerClass = isReel ? 'aspect-[9/16]' : 'aspect-video';

  return (
    <div className="group relative flex flex-col bg-white border border-slate-200 rounded-lg overflow-hidden transition-shadow hover:shadow-xl duration-300">
      {/* Thumbnail */}
      <div className={`relative w-full overflow-hidden ${containerClass}`}>
        <img
          src={video.thumbnailUrl}
          alt={video.title}
          className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-300"
        />
         <Link to={`/instructors/${instructor.id}`} className="absolute inset-0">
            <div className="absolute inset-0 bg-black/20 group-hover:bg-black/40 transition-colors flex items-center justify-center">
                <PlayIcon className="w-12 h-12 text-white/70 transform group-hover:scale-110 transition-transform duration-300" />
            </div>
        </Link>
        <span className="absolute bottom-2 right-2 bg-black/60 text-white text-xs px-2 py-1 rounded-md">{video.duration}</span>
        <span className="absolute top-2 left-2 bg-emerald-600 text-white text-xs px-2 py-1 rounded-full font-semibold capitalize">{video.type}</span>

      </div>

      {/* Video Info */}
      <div className="p-4 flex flex-col flex-grow">
        <h4 className="font-semibold text-slate-800 line-clamp-2">
           <Link to={`/instructors/${instructor.id}`} className="hover:text-emerald-600 transition-colors">
             {video.title}
           </Link>
        </h4>

        {/* Instructor Info */}
        <div className="mt-3">
            <Link to={`/instructors/${instructor.id}`} className="flex items-center gap-2 group/instructor">
                <img className="h-8 w-8 rounded-full" src={instructor.avatarUrl} alt={instructor.name} />
                <div>
                    <p className="text-sm font-medium text-slate-700 group-hover/instructor:text-emerald-600 transition-colors">{instructor.name}</p>
                    <p className="text-xs text-slate-500">{video.uploadedAt}</p>
                </div>
            </Link>
        </div>

        {/* Stats */}
        <div className="flex-grow"></div>
        <div className="mt-3 flex items-center justify-between text-slate-500">
            <div className="flex items-center gap-1">
                <EyeIcon className="w-4 h-4" />
                <span className="text-xs font-medium">{formatViews(video.views)}</span>
            </div>
            <div className="flex items-center gap-1">
                <HeartIcon className="w-4 h-4" />
                <span className="text-xs font-medium">{formatViews(video.likes)}</span>
            </div>
        </div>
      </div>
    </div>
  );
};

export default VideoCard;