
import { Instructor, Course, Video, InstructorPlatformPlan, StudentMembershipPlan, Ad, Product, LiveClass, SubscriptionPlan, Challenge, Workshop, ForumCategory, BookingSlot, UserStats, Badge, MusicTrack, InstructorAnalytics, CorporatePlan, Retreat, AdCampaign } from '../types';
import TrophyIcon from '../components/icons/TrophyIcon';
import StarIcon from '../components/icons/StarIcon';
import HeartIcon from '../components/icons/HeartIcon';

export const mockInstructors: Instructor[] = [
  {
    id: 1,
    name: 'Anjali Sharma',
    avatarUrl: 'https://i.pravatar.cc/150?u=anjali',
    bio: 'Anjali is a certified Hatha and Vinyasa instructor with over 10 years of experience. She believes in making yoga accessible to everyone, focusing on alignment and mindful movement.',
    location: 'Mumbai, India',
    rating: 4.9,
    reviewCount: 215,
    languages: ['English', 'Hindi', 'Marathi'],
    specialties: ['Hatha', 'Vinyasa', 'Restorative'],
    sessionTypes: ['Group', '1-on-1'],
    pricing: { monthly: 2000, quarterly: 5500, yearly: 20000 },
    socialLinks: { instagram: '#', twitter: '#' },
    followers: 1250,
    students: 830,
  },
  {
    id: 2,
    name: 'Rohan Mehta',
    avatarUrl: 'https://i.pravatar.cc/150?u=rohan',
    bio: 'Rohan specializes in dynamic Vinyasa flows and breathwork. His classes are energetic and designed to help students break through physical and mental barriers.',
    location: 'Delhi, India',
    rating: 4.8,
    reviewCount: 180,
    languages: ['English', 'Hindi', 'Punjabi'],
    specialties: ['Vinyasa Flow', 'Power Yoga', 'Pranayama'],
    sessionTypes: ['Group', '1-on-1', 'Kids'],
    pricing: { monthly: 2500, quarterly: 7000, yearly: 25000 },
    socialLinks: { instagram: '#' },
    followers: 2100,
    students: 1500,
  },
  {
    id: 3,
    name: 'Priya Desai',
    avatarUrl: 'https://i.pravatar.cc/150?u=priya',
    bio: 'A dedicated practitioner of Ashtanga yoga, Priya guides students through the traditional series with precision and care. Her focus on discipline inspires students to deepen their practice.',
    location: 'Bengaluru, India',
    rating: 4.9,
    reviewCount: 150,
    languages: ['English', 'Kannada'],
    specialties: ['Ashtanga', 'Mysore Style'],
    sessionTypes: ['Group', '1-on-1'],
    pricing: { monthly: 3000, quarterly: 8500, yearly: 30000 },
    socialLinks: { twitter: '#' },
    followers: 980,
    students: 600,
  },
  {
    id: 4,
    name: 'Kumar Rajan',
    avatarUrl: 'https://i.pravatar.cc/150?u=kumar',
    bio: 'Kumar is a master of Siddha Yoga and Pranayama, teaching ancient techniques passed down through generations. His calming presence provides a truly authentic experience.',
    location: 'Chennai, India',
    rating: 5.0,
    reviewCount: 320,
    languages: ['English', 'Tamil'],
    specialties: ['Siddha Yoga', 'Meditation', 'Yoga for Seniors'],
    sessionTypes: ['Group', '1-on-1', 'Seniors'],
    pricing: { monthly: 2200, quarterly: 6000, yearly: 22000 },
    socialLinks: { instagram: '#', twitter: '#' },
    followers: 3500,
    students: 2200,
  },
  {
    id: 5,
    name: 'Meera Iyer',
    avatarUrl: 'https://i.pravatar.cc/150?u=meera',
    bio: 'Meera focuses on prenatal and postnatal yoga, helping mothers navigate their journey with strength and grace. Her gentle approach is perfect for all stages of pregnancy.',
    location: 'Hyderabad, India',
    rating: 4.9,
    reviewCount: 95,
    languages: ['English', 'Telugu'],
    specialties: ['Prenatal Yoga', 'Postnatal Yoga', 'Gentle Flow'],
    sessionTypes: ['Group', '1-on-1'],
    pricing: { monthly: 2800, quarterly: 8000, yearly: 29000 },
    socialLinks: { instagram: '#' },
    followers: 800,
    students: 450,
  },
  {
    id: 6,
    name: 'Sandeep Singh',
    avatarUrl: 'https://i.pravatar.cc/150?u=sandeep',
    bio: 'An expert in Iyengar yoga, Sandeep emphasizes precision and alignment, using props to help students achieve perfect form in every asana.',
    location: 'Pune, India',
    rating: 4.8,
    reviewCount: 110,
    languages: ['English', 'Hindi', 'Marathi'],
    specialties: ['Iyengar Yoga', 'Props & Alignment', 'Yoga for Seniors'],
    sessionTypes: ['Group', 'Seniors'],
    pricing: { monthly: 2600, quarterly: 7200, yearly: 26000 },
    socialLinks: {},
    followers: 1100,
    students: 700,
  }
];

export const mockInstructorPlans: InstructorPlatformPlan[] = [
    {
        id: 1,
        name: 'Monthly Pro',
        price: 999,
        frequency: '/ month',
        description: 'Get listed on the platform and start reaching students immediately.',
        features: [
            'Full profile customization',
            'Appear in search results',
            'Direct messaging with students',
            'Basic analytics'
        ],
        isPopular: false,
    },
    {
        id: 2,
        name: 'Quarterly Pro',
        price: 2499,
        frequency: '/ 3 months',
        description: 'Best value for serious instructors looking to grow their business.',
        features: [
            'All features of Monthly Pro',
            'Priority support',
            'Promote your profile with ads',
            'Advanced performance analytics'
        ],
        isPopular: true,
    }
];

export const mockStudentPlans: StudentMembershipPlan[] = [
    {
        id: 1,
        name: 'Explorer Pass',
        price: 499,
        frequency: '/ month',
        description: 'Perfect for getting started and trying out different classes.',
        features: [
            '5 Group Class Credits',
            'Book any instructor',
            'Access to community forums',
            'Cancel anytime'
        ],
        isPopular: false,
    },
    {
        id: 2,
        name: 'Devotee Membership',
        price: 1499,
        frequency: '/ month',
        description: 'Our most popular plan for the dedicated practitioner.',
        features: [
            '20 Group Class Credits',
            '2 1-on-1 Session Credits',
            'Priority booking for workshops',
            '10% off instructor yearly plans'
        ],
        isPopular: true,
    },
    {
        id: 3,
        name: 'Immersion Pack',
        price: 3999,
        frequency: '/ quarter',
        description: 'The ultimate package for a fully immersive yoga experience.',
        features: [
            'Unlimited Group Classes',
            '8 1-on-1 Session Credits',
            'Free access to all workshops',
            'Personalized AI recommendations'
        ],
        isPopular: false,
    }
];

export const mockCourses: Course[] = [
  {
    id: 1,
    title: 'Foundations of Hatha Yoga',
    instructorId: 1,
    language: 'English',
    description: 'A comprehensive introduction to the fundamental postures and principles of Hatha yoga.',
    imageUrl: 'https://picsum.photos/seed/hatha/600/400',
    level: 'Beginner',
    duration: '6 Weeks',
  },
  {
    id: 2,
    title: 'Vinyasa Flow & Breathwork',
    instructorId: 2,
    language: 'Hindi',
    description: 'Connect movement with breath in this dynamic Vinyasa flow class.',
    imageUrl: 'https://picsum.photos/seed/vinyasa/600/400',
    level: 'Intermediate',
    duration: '8 Weeks',
  }
];

export const mockVideos: Video[] = [
  {
    id: 1,
    instructorId: 2,
    type: 'reel',
    title: '30-Second Morning Stretch',
    thumbnailUrl: 'https://picsum.photos/seed/reel1/400/700',
    duration: '0:32',
    views: 12500,
    likes: 1200,
    uploadedAt: '1 day ago',
  },
  {
    id: 2,
    instructorId: 1,
    type: 'short-video',
    title: '3-Minute Mindful Breathing',
    thumbnailUrl: 'https://picsum.photos/seed/video1/700/400',
    duration: '3:15',
    views: 8400,
    likes: 980,
    uploadedAt: '3 days ago',
  }
];

export const mockAd: Ad = {
  imageUrl: 'https://picsum.photos/seed/ad1/800/400',
  title: 'Eco-Friendly Yoga Mats',
  description: 'Enhance your practice with our sustainable and non-slip yoga mats. Made from all-natural cork and rubber.',
  link: '#',
};

export const mockProducts: Product[] = [
    { id: 1, name: 'Eco-Flow Yoga Mat', category: 'Mats', imageUrl: 'https://picsum.photos/seed/mat/400/400', price: 79, rating: 4.8, reviewCount: 124, description: 'A premium, eco-friendly mat for all styles of yoga.' },
    { id: 2, name: 'Sattva Cork Block', category: 'Props', imageUrl: 'https://picsum.photos/seed/block/400/400', price: 24, rating: 4.9, reviewCount: 98, description: 'Sturdy and sustainable cork block for support.' },
    { id: 3, name: 'Dhyana Meditation Cushion', category: 'Cushions', imageUrl: 'https://picsum.photos/seed/cushion/400/400', price: 45, rating: 4.7, reviewCount: 75, description: 'Comfortable cushion for longer meditation sessions.' },
    { id: 4, name: 'Ganga Grip Yoga Towel', category: 'Accessories', imageUrl: 'https://picsum.photos/seed/towel/400/400', price: 35, originalPrice: 40, rating: 4.6, reviewCount: 88, description: 'Absorbent and non-slip towel for hot yoga.' }
];

export const mockLiveClasses: LiveClass[] = [
    { id: 1, title: 'Sunrise Vinyasa Flow', instructorId: 2, startTime: new Date(new Date().setHours(7, 0, 0)), durationMinutes: 60, level: 'All Levels', isLive: true },
    { id: 2, title: 'Gentle Hatha & Stretch', instructorId: 1, startTime: new Date(new Date().setHours(9, 0, 0)), durationMinutes: 45, level: 'Beginner', isLive: false },
    { id: 3, title: 'Power Yoga Lunch Break', instructorId: 3, startTime: new Date(new Date().setHours(12, 30, 0)), durationMinutes: 45, level: 'Intermediate', isLive: false },
    { id: 4, title: 'Restorative Evening Wind-Down', instructorId: 4, startTime: new Date(new Date().setHours(20, 0, 0)), durationMinutes: 60, level: 'All Levels', isLive: false },
];

export const mockSubscriptionPlans: SubscriptionPlan[] = [
    { id: 1, name: 'Monthly Unlimited', price: 2999, frequency: '/ month', description: 'Full access to all classes and content.', features: ['Unlimited Group Classes', 'Unlimited Video Library', 'Community Access'], isPopular: true, type: 'unlimited' },
    { id: 2, name: 'Yearly Unlimited', price: 29999, frequency: '/ year', description: 'Save big with an annual commitment.', features: ['All Monthly benefits', '2 Months Free', 'Priority Workshop Booking'], isPopular: false, type: 'unlimited' },
    { id: 3, name: '5 Class Pack', price: 1999, frequency: '/ one-time', description: 'Flexible pack for occasional practice.', features: ['5 Class Pack Credits', 'Valid for 3 months', 'Book any instructor'], isPopular: false, type: 'pack' },
];

export const mockChallenges: Challenge[] = [
    { id: 1, title: '30-Day Yoga Journey', description: 'A transformative challenge to build a consistent practice.', imageUrl: 'https://picsum.photos/seed/challenge1/600/400', instructorId: 1, level: 'All Levels', durationDays: 30, participants: 1204, dailyContent: Array.from({length: 30}, (_, i) => ({day: i+1, title: `Day ${i+1}: Foundations`, videoId: 2, completed: i < 5})) },
    { id: 2, title: '7-Day Core Strength', description: 'Fire up your core with this week-long intensive.', imageUrl: 'https://picsum.photos/seed/challenge2/600/400', instructorId: 2, level: 'Intermediate', durationDays: 7, participants: 876, dailyContent: Array.from({length: 7}, (_, i) => ({day: i+1, title: `Day ${i+1}: Core Flow`, videoId: 1, completed: i < 2})) }
];

export const mockWorkshops: Workshop[] = [
    { id: 1, title: 'Inversions & Arm Balances', instructorId: 3, imageUrl: 'https://picsum.photos/seed/workshop1/600/400', level: 'Intermediate', date: new Date(Date.now() + 10 * 24 * 60 * 60 * 1000), durationHours: 2, price: 1500, slots: 20, slotsTaken: 15 },
    { id: 2, title: 'Intro to Pranayama', instructorId: 4, imageUrl: 'https://picsum.photos/seed/workshop2/600/400', level: 'Beginner', date: new Date(Date.now() + 15 * 24 * 60 * 60 * 1000), durationHours: 1.5, price: 1000, slots: 25, slotsTaken: 10 },
];

export const mockForumCategories: ForumCategory[] = [
    { id: 1, name: 'General Discussion', description: 'Talk about anything and everything yoga-related.', threadCount: 124, postCount: 1102 },
    { id: 2, name: 'Asana & Alignment', description: 'Questions and tips about poses and proper form.', threadCount: 88, postCount: 754 },
    { id: 3, name: 'Meditation & Mindfulness', description: 'Share your experiences with meditation.', threadCount: 45, postCount: 498 },
];

export const mockBookingSlots: BookingSlot[] = Array.from({ length: 10 }, (_, i) => {
    const date = new Date();
    date.setDate(date.getDate() + Math.floor(i/2) + 1);
    date.setHours(9 + (i%2) * 2, 0, 0, 0);
    return {
        id: i + 1,
        instructorId: 1, // Example for instructor 1
        startTime: date,
        isBooked: i % 4 === 0,
    };
});

// MOCK DATA FOR 6 NEW FEATURES

export const mockUserStats: UserStats = {
    minutesPracticed: 1245,
    classesTaken: 32,
    currentStreak: 7,
};

export const mockBadges: Badge[] = [
    { id: 1, name: 'Sunrise Yogi', description: 'Completed a class before 7 AM.', icon: StarIcon },
    { id: 2, name: 'Weekly Warrior', description: 'Completed 7 classes in one week.', icon: TrophyIcon },
    { id: 3, name: 'Challenge Champion', description: 'Completed your first challenge.', icon: HeartIcon },
    { id: 4, name: 'Zen Seeker', description: 'Logged 10 meditation sessions.', icon: StarIcon },
];

export const mockMusicTracks: MusicTrack[] = [
    { id: 1, title: 'Ambient Flow', artist: 'Yoga Hub', src: '#' },
    { id: 2, title: 'Peaceful Meditation', artist: 'Yoga Hub', src: '#' },
    { id: 3, title: 'Nature Sounds', artist: 'Yoga Hub', src: '#' },
];

export const mockAnalytics: InstructorAnalytics = {
    revenue: [
        { month: 'Jan', amount: 4000 }, { month: 'Feb', amount: 3000 }, { month: 'Mar', amount: 5000 },
        { month: 'Apr', amount: 4500 }, { month: 'May', amount: 6000 }, { month: 'Jun', amount: 7500 },
    ],
    revenueSource: [
        { source: 'Subscriptions', value: 65 }, { source: 'Workshops', value: 25 }, { source: 'Store', value: 10 },
    ],
    studentGrowth: [
        { month: 'Jan', count: 50 }, { month: 'Feb', count: 60 }, { month: 'Mar', count: 75 },
        { month: 'Apr', count: 80 }, { month: 'May', count: 95 }, { month: 'Jun', count: 110 },
    ],
    kpis: [
        { name: 'Monthly Revenue', value: '₹75,000', change: 12.5 },
        { name: 'Active Students', value: '110', change: 8.2 },
        { name: 'Avg. Rating', value: '4.9/5', change: 0.1 },
    ]
};

export const mockCorporatePlans: CorporatePlan[] = [
    { id: 1, name: 'Team Starter', price: '₹15,000/month', description: 'For small teams up to 20 employees.', features: ['Access to all group classes', '1 private team workshop/month', 'Basic progress reporting'] },
    { id: 2, name: 'Business Growth', price: '₹40,000/month', description: 'For medium-sized companies up to 100 employees.', features: ['Everything in Team Starter', '4 private team workshops/month', 'Dedicated account manager'] },
    { id: 3, name: 'Enterprise', price: 'Contact Us', description: 'Custom solutions for large organizations.', features: ['Fully customized program', 'On-site classes & retreats', 'Advanced wellness analytics'] },
];

export const mockRetreats: Retreat[] = [
    { id: 1, title: 'Bali Bliss Yoga Retreat', location: 'Ubud, Bali', instructorId: 1, imageUrl: 'https://picsum.photos/seed/retreat1/800/600', startDate: new Date('2024-10-15'), endDate: new Date('2024-10-22'), price: 250000, description: 'A 7-day immersive yoga and meditation experience in the heart of Bali. Reconnect with nature and yourself.' },
    { id: 2, title: 'Himalayan Hatha Escape', location: 'Rishikesh, India', instructorId: 4, imageUrl: 'https://picsum.photos/seed/retreat2/800/600', startDate: new Date('2024-11-05'), endDate: new Date('2024-11-12'), price: 180000, description: 'Deepen your Hatha practice on the banks of the Ganges. Includes daily treks and spiritual discourses.' },
];

export const mockAdCampaigns: AdCampaign[] = [
  {
    id: 1,
    name: 'Summer Vinyasa Promotion',
    adType: 'instructor_promotion',
    status: 'active',
    impressions: 15234,
    clicks: 876,
    conversions: 45,
    budget: 10000,
    daily_spent: 450,
    startDate: '2024-07-01',
    endDate: '2024-07-31',
  },
  {
    id: 2,
    name: 'New Eco-Friendly Mats Launch',
    adType: 'banner',
    status: 'completed',
    impressions: 50123,
    clicks: 2345,
    conversions: 152,
    budget: 25000,
    daily_spent: 0,
    startDate: '2024-06-01',
    endDate: '2024-06-30',
  },
  {
    id: 3,
    name: 'Mindfulness Meditation Workshop Ad',
    adType: 'video',
    status: 'paused',
    impressions: 5400,
    clicks: 123,
    conversions: 12,
    budget: 5000,
    daily_spent: 150,
    startDate: '2024-07-15',
    endDate: '2024-08-15',
  },
   {
    id: 4,
    name: 'Beginner Hatha Course - Q3 Drive',
    adType: 'instructor_promotion',
    status: 'pending',
    impressions: 0,
    clicks: 0,
    conversions: 0,
    budget: 7500,
    daily_spent: 0,
    startDate: '2024-08-01',
    endDate: '2024-08-31',
  },
];