
import React, { useState, useMemo } from 'react';
import { useParams, Link, useNavigate, useLocation } from 'react-router-dom';
import { mockSubscriptionPlans, mockInstructorPlans } from '../data/mockData';
import NotFound from './NotFound';
import CreditCardIcon from '../components/icons/CreditCardIcon';
import LockClosedIcon from '../components/icons/LockClosedIcon';
import CheckIcon from '../components/icons/CheckIcon';
import { InstructorPlatformPlan, SubscriptionPlan } from '../types';

const Checkout: React.FC = () => {
    const { planId } = useParams();
    const navigate = useNavigate();
    const location = useLocation();
    const [isProcessing, setIsProcessing] = useState(false);
    const [isSuccess, setIsSuccess] = useState(false);

    const isInstructorPlan = location.pathname.includes('/instructor/');

    const plan = useMemo(() => {
        const plans: (SubscriptionPlan | InstructorPlatformPlan)[] = isInstructorPlan ? mockInstructorPlans : mockSubscriptionPlans;
        return plans.find(p => p.id === Number(planId));
    }, [planId, isInstructorPlan]);

    const handlePayment = (e: React.FormEvent) => {
        e.preventDefault();
        setIsProcessing(true);
        setTimeout(() => {
            setIsProcessing(false);
            setIsSuccess(true);
            setTimeout(() => {
                navigate('/dashboard');
            }, 3000);
        }, 2000);
    };

    if (!plan) {
        return <NotFound />;
    }
    
    if (isSuccess) {
        return (
            <div className="text-center py-20 max-w-2xl mx-auto">
                <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-green-100">
                    <CheckIcon className="h-6 w-6 text-green-600" aria-hidden="true" />
                </div>
                <h2 className="mt-4 text-3xl font-bold tracking-tight text-slate-900 sm:text-4xl">Payment Successful!</h2>
                <p className="mt-4 text-lg text-slate-600">
                    Thank you for your purchase! Your access to <strong>{plan.name}</strong> is now active. You'll be redirected to the dashboard shortly.
                </p>
                <div className="mt-6">
                    <Link
                        to="/dashboard"
                        className="rounded-md bg-emerald-600 px-3.5 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-emerald-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-emerald-600"
                    >
                        Go to Dashboard
                    </Link>
                </div>
            </div>
        )
    }

    return (
        <div className="relative mx-auto w-full bg-white">
            <div className="grid grid-cols-1 md:grid-cols-2">
                {/* Contact Info */}
                <div className="bg-slate-50 py-12 px-4 sm:px-6 lg:px-8">
                    <div className="mx-auto max-w-lg">
                        <Link to={isInstructorPlan ? "/for-instructors" : "/subscribe"} className="text-emerald-600 font-semibold text-sm hover:underline">&larr; Back to plans</Link>
                        <h2 className="mt-6 text-3xl font-bold tracking-tight text-slate-900">Payment details</h2>
                        <p className="mt-3 text-slate-600">Complete your purchase by providing your payment details.</p>

                        <form onSubmit={handlePayment} className="mt-8 space-y-6">
                            <div>
                                <label htmlFor="email-address" className="block text-sm font-medium text-gray-700">Email address</label>
                                <div className="mt-1">
                                    <input type="email" id="email-address" name="email" autoComplete="email" required className="block w-full rounded-md border-gray-300 shadow-sm focus:border-emerald-500 focus:ring-emerald-500 sm:text-sm p-2" placeholder="you@example.com" />
                                </div>
                            </div>

                            <div>
                                <label htmlFor="card-number" className="block text-sm font-medium text-gray-700">Card details</label>
                                <div className="mt-1 relative">
                                    <input type="text" id="card-number" name="card-number" required className="block w-full rounded-md border-gray-300 shadow-sm focus:border-emerald-500 focus:ring-emerald-500 sm:text-sm p-2 pl-10" placeholder="0000 0000 0000 0000" />
                                    <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                                        <CreditCardIcon className="h-5 w-5 text-gray-400" aria-hidden="true" />
                                    </div>
                                </div>
                            </div>
                            
                            <div>
                                <label htmlFor="name-on-card" className="block text-sm font-medium text-gray-700">Name on card</label>
                                <div className="mt-1">
                                    <input type="text" id="name-on-card" name="name-on-card" autoComplete="cc-name" required className="block w-full rounded-md border-gray-300 shadow-sm focus:border-emerald-500 focus:ring-emerald-500 sm:text-sm p-2" />
                                </div>
                            </div>

                            <div className="flex gap-4">
                                <div className="flex-1">
                                    <label htmlFor="expiration-date" className="block text-sm font-medium text-gray-700">Expiration date (MM/YY)</label>
                                    <div className="mt-1">
                                        <input type="text" name="expiration-date" id="expiration-date" autoComplete="cc-exp" required className="block w-full rounded-md border-gray-300 shadow-sm focus:border-emerald-500 focus:ring-emerald-500 sm:text-sm p-2" placeholder="MM / YY" />
                                    </div>
                                </div>
                                <div className="flex-1">
                                    <label htmlFor="cvc" className="block text-sm font-medium text-gray-700">CVC</label>
                                    <div className="mt-1">
                                        <input type="text" name="cvc" id="cvc" autoComplete="csc" required className="block w-full rounded-md border-gray-300 shadow-sm focus:border-emerald-500 focus:ring-emerald-500 sm:text-sm p-2" />
                                    </div>
                                </div>
                            </div>
                            
                            <button type="submit" disabled={isProcessing} className="w-full flex justify-center items-center gap-2 rounded-md border border-transparent bg-emerald-600 py-3 px-4 text-base font-medium text-white shadow-sm hover:bg-emerald-700 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:ring-offset-2 disabled:bg-slate-400">
                                {isProcessing ? 'Processing...' : `Pay ₹${plan.price}`}
                            </button>

                            <div className="flex items-center justify-center gap-2 mt-4 text-sm text-slate-500">
                                <LockClosedIcon className="w-4 h-4" />
                                <span>Secure SSL Encrypted Payment</span>
                            </div>
                        </form>
                    </div>
                </div>

                {/* Order summary */}
                <div className="py-12 px-4 sm:px-6 lg:px-8">
                     <div className="mx-auto max-w-lg">
                        <h2 className="text-3xl font-bold tracking-tight text-slate-900">Order summary</h2>
                        <div className="mt-8">
                            <div className="flow-root">
                                <div className="divide-y divide-gray-200">
                                    <div className="flex items-center justify-between py-6">
                                        <div>
                                            <p className="font-medium text-gray-900">{plan.name}</p>
                                            <p className="mt-1 text-sm text-gray-500">{plan.description}</p>
                                        </div>
                                        <p className="font-medium text-gray-900">₹{plan.price.toFixed(2)}</p>
                                    </div>
                                </div>

                                <dl className="space-y-4 border-t border-gray-200 pt-6 text-sm font-medium text-gray-500">
                                    <div className="flex justify-between">
                                        <dt>Subtotal</dt>
                                        <dd className="text-gray-900">₹{plan.price.toFixed(2)}</dd>
                                    </div>
                                    <div className="flex justify-between">
                                        <dt>Taxes</dt>
                                        <dd className="text-gray-900">₹0.00</dd>
                                    </div>
                                    <div className="flex items-center justify-between border-t border-gray-200 pt-4 text-base text-gray-900">
                                        <dt>Total</dt>
                                        <dd>₹{plan.price.toFixed(2)}</dd>
                                    </div>
                                </dl>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    );
};

export default Checkout;
