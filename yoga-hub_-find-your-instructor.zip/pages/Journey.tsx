
import React from 'react';
import { mockUserStats, mockBadges } from '../data/mockData';
import StatCard from '../components/StatCard';
import Badge from '../components/Badge';
import ClockIcon from '../components/ClockIcon';
import FilmIcon from '../components/icons/FilmIcon';
import UsersIcon from '../components/icons/UsersIcon';
import TrophyIcon from '../components/icons/TrophyIcon';

const Journey: React.FC = () => {
  return (
    <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
      <div className="space-y-12">
        <div className="text-center">
          <h1 className="text-4xl font-extrabold tracking-tight text-slate-900 sm:text-5xl">Your Yoga Journey</h1>
          <p className="mt-4 max-w-2xl mx-auto text-xl text-slate-600">
            Track your progress, celebrate your milestones, and stay motivated.
          </p>
        </div>

        {/* Stats Section */}
        <div>
          <h2 className="text-2xl font-bold text-slate-800 mb-4">Your Progress</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <StatCard icon={<ClockIcon className="w-7 h-7" />} label="Minutes Practiced" value={mockUserStats.minutesPracticed.toLocaleString()} />
            <StatCard icon={<FilmIcon className="w-7 h-7" />} label="Classes Taken" value={mockUserStats.classesTaken} />
            <StatCard icon={<UsersIcon className="w-7 h-7" />} label="Practice Streak" value={`${mockUserStats.currentStreak} Days`} />
          </div>
        </div>

        {/* Achievements Section */}
        <div>
          <div className="flex items-center gap-3 mb-4">
              <TrophyIcon className="w-7 h-7 text-amber-500" />
              <h2 className="text-2xl font-bold text-slate-800">Achievements</h2>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {mockBadges.map(badge => (
              <Badge key={badge.id} badge={badge} unlocked={true} />
            ))}
            {mockBadges.map(badge => ( // Simulating some locked badges
              <Badge key={badge.id + 10} badge={{...badge, id: badge.id + 10}} unlocked={false} />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Journey;