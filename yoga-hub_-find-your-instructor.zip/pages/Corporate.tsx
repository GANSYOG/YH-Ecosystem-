
import React from 'react';
import { mockCorporatePlans } from '../data/mockData';
import CheckIcon from '../components/icons/CheckIcon';
import BriefcaseIcon from '../components/icons/BriefcaseIcon';

const Corporate: React.FC = () => {
  return (
    <div className="bg-white">
        {/* Hero Section */}
        <div className="relative bg-slate-800">
            <div className="absolute inset-0">
                <img className="w-full h-full object-cover" src="https://picsum.photos/seed/corporate/1920/1080" alt="Team doing yoga" />
                <div className="absolute inset-0 bg-emerald-900/60 mix-blend-multiply"></div>
            </div>
            <div className="relative container mx-auto px-4 sm:px-6 lg:px-8 py-24 sm:py-32 text-center text-white">
                <h1 className="text-4xl sm:text-5xl md:text-6xl font-extrabold tracking-tight">
                    Invest in Your Team's Well-being
                </h1>
                <p className="mt-6 max-w-3xl mx-auto text-lg sm:text-xl text-slate-200">
                    Boost productivity, reduce stress, and foster a positive work environment with our tailored corporate yoga and wellness programs.
                </p>
                <div className="mt-8">
                     <a href="mailto:corporate@yogahub.com" className="inline-block bg-emerald-600 text-white px-8 py-3 rounded-md text-base font-semibold hover:bg-emerald-500 transition-transform duration-200 hover:scale-105">
                        Request a Demo
                    </a>
                </div>
            </div>
        </div>

        {/* Benefits Section */}
        <div className="py-16 sm:py-24">
             <div className="container mx-auto px-4 sm:px-6 lg:px-8">
                 <div className="text-center">
                    <h2 className="text-base font-semibold text-emerald-600 uppercase tracking-wider">Why Yoga Hub?</h2>
                    <p className="mt-2 text-3xl font-bold tracking-tight text-slate-900 sm:text-4xl">A Healthier Team is a Happier Team</p>
                </div>
                 <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-10">
                    <div className="text-center">
                        <BriefcaseIcon className="mx-auto h-12 w-12 text-emerald-600" />
                        <h3 className="mt-4 text-xl font-bold text-slate-800">Boost Productivity</h3>
                        <p className="mt-2 text-slate-600">Mindful practices improve focus and concentration, leading to a more efficient workforce.</p>
                    </div>
                     <div className="text-center">
                        <BriefcaseIcon className="mx-auto h-12 w-12 text-emerald-600" />
                        <h3 className="mt-4 text-xl font-bold text-slate-800">Reduce Stress</h3>
                        <p className="mt-2 text-slate-600">Our programs are designed to lower stress levels and prevent burnout.</p>
                    </div>
                     <div className="text-center">
                        <BriefcaseIcon className="mx-auto h-12 w-12 text-emerald-600" />
                        <h3 className="mt-4 text-xl font-bold text-slate-800">Enhance Culture</h3>
                        <p className="mt-2 text-slate-600">Promote a positive company culture centered around health and well-being.</p>
                    </div>
                 </div>
             </div>
        </div>
        
        {/* Pricing Section */}
        <div className="bg-slate-50 py-16 sm:py-24">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8">
                 <div className="text-center">
                    <h2 className="text-3xl font-bold tracking-tight text-slate-900 sm:text-4xl">Flexible Plans for Every Business</h2>
                    <p className="mt-4 max-w-2xl mx-auto text-lg text-slate-600">
                        Choose a plan that fits your company's size and needs.
                    </p>
                </div>
                <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-8">
                    {mockCorporatePlans.map(plan => (
                        <div key={plan.id} className="p-8 rounded-2xl bg-white shadow-lg border border-slate-200 flex flex-col">
                             <h3 className="text-2xl font-semibold leading-6 text-slate-900">{plan.name}</h3>
                              <p className="mt-4 flex items-baseline gap-x-2">
                                <span className="text-4xl font-bold tracking-tight text-slate-900">{plan.price}</span>
                              </p>
                              <p className="mt-6 text-base leading-7 text-slate-600">{plan.description}</p>
                              <ul role="list" className="mt-8 space-y-3 text-sm leading-6 text-slate-600 flex-grow">
                                {plan.features.map((feature) => (
                                  <li key={feature} className="flex gap-x-3">
                                    <CheckIcon className="h-6 w-5 flex-none text-emerald-500" aria-hidden="true" />
                                    {feature}
                                  </li>
                                ))}
                              </ul>
                               <a href="mailto:corporate@yogahub.com" className="mt-8 block rounded-md px-3.5 py-2.5 text-center text-sm font-semibold bg-emerald-600 text-white shadow-md hover:bg-emerald-500 focus-visible:outline-emerald-600 hover:scale-105">
                                Contact Sales
                              </a>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    </div>
  );
};

export default Corporate;
