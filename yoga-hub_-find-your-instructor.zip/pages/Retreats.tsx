
import React, { useMemo } from 'react';
import { mockRetreats, mockInstructors } from '../data/mockData';
import RetreatCard from '../components/RetreatCard';
import { Instructor } from '../types';

const Retreats: React.FC = () => {
    const retreatsWithInstructors = useMemo(() => {
        return mockRetreats.map(retreat => {
            const instructor = mockInstructors.find(i => i.id === retreat.instructorId);
            return { retreat, instructor };
        }).filter(item => item.instructor);
    }, []);

    return (
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
            <div className="space-y-12">
                <div className="text-center">
                    <h1 className="text-4xl font-extrabold tracking-tight text-slate-900 sm:text-5xl">Global Yoga Retreats</h1>
                    <p className="mt-4 max-w-2xl mx-auto text-xl text-slate-600">
                        Immerse yourself in transformative experiences. Discover and book yoga retreats in breathtaking locations worldwide.
                    </p>
                </div>

                <div>
                    <div className="grid grid-cols-1 gap-y-10 gap-x-8 md:grid-cols-2">
                        {retreatsWithInstructors.map(({ retreat, instructor }) => (
                            <RetreatCard key={retreat.id} retreat={retreat} instructor={instructor as Instructor} />
                        ))}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Retreats;