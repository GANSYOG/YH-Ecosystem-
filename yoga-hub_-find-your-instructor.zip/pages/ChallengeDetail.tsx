
import React, { useMemo } from 'react';
import { useParams, Link } from 'react-router-dom';
import { mockChallenges, mockInstructors, mockVideos } from '../data/mockData';
import NotFound from './NotFound';
import CheckIcon from '../components/icons/CheckIcon';
import PlayIcon from '../components/icons/PlayIcon';
import UsersIcon from '../components/icons/UsersIcon';

const ChallengeDetail: React.FC = () => {
    const { challengeId } = useParams();

    const { challenge, instructor } = useMemo(() => {
        const id = Number(challengeId);
        const challengeData = mockChallenges.find(c => c.id === id);
        if (!challengeData) {
            return { challenge: null, instructor: null };
        }
        const instructorData = mockInstructors.find(i => i.id === challengeData.instructorId);
        return { challenge: challengeData, instructor: instructorData };
    }, [challengeId]);

    if (!challenge || !instructor) {
        return <NotFound />;
    }

    const progress = (challenge.dailyContent.filter(d => d.completed).length / challenge.durationDays) * 100;
    const completedDays = challenge.dailyContent.filter(d => d.completed).length;

    return (
        <div>
            <div className="relative bg-slate-800 rounded-lg shadow-xl overflow-hidden -mx-4 -mt-8 sm:-mx-6 lg:-mx-8">
                <img src={challenge.imageUrl} alt={challenge.title} className="absolute inset-0 w-full h-full object-cover opacity-30" />
                <div className="relative p-8 md:p-12 text-white">
                    <p className="text-sm font-bold uppercase tracking-widest text-emerald-400">Yoga Challenge</p>
                    <h1 className="text-4xl lg:text-5xl font-extrabold mt-2">{challenge.title}</h1>
                    <p className="mt-4 max-w-2xl text-lg text-slate-300">{challenge.description}</p>
                    <div className="mt-6 flex items-center gap-6">
                         <Link to={`/instructors/${instructor.id}`} className="flex items-center gap-3">
                            <img src={instructor.avatarUrl} alt={instructor.name} className="w-12 h-12 rounded-full ring-2 ring-white" />
                            <div>
                                <p className="text-sm text-slate-300">With</p>
                                <p className="font-semibold text-white">{instructor.name}</p>
                            </div>
                        </Link>
                         <div className="flex items-center gap-2 text-white">
                            <UsersIcon className="w-5 h-5" />
                            <span className="font-semibold">{challenge.participants.toLocaleString()}</span>
                            <span className="text-slate-300">participants</span>
                        </div>
                    </div>
                </div>
            </div>
            
            <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                    {/* Left side: Daily content list */}
                    <div className="md:col-span-2 bg-white p-6 rounded-lg shadow-md">
                         <h2 className="text-2xl font-bold text-slate-800 mb-4">Daily Content</h2>
                         <ul className="space-y-3">
                            {challenge.dailyContent.map(day => {
                                const video = mockVideos.find(v => v.id === day.videoId);
                                return (
                                    <li key={day.day} className={`p-4 rounded-lg flex items-center gap-4 transition ${day.completed ? 'bg-emerald-50' : 'bg-slate-50'}`}>
                                        <div className={`w-10 h-10 rounded-full flex-shrink-0 flex items-center justify-center font-bold text-lg ${day.completed ? 'bg-emerald-500 text-white' : 'bg-slate-200 text-slate-600'}`}>
                                            {day.completed ? <CheckIcon className="w-6 h-6"/> : day.day}
                                        </div>
                                        <div className="flex-1">
                                            <p className={`font-semibold ${day.completed ? 'text-slate-500 line-through' : 'text-slate-800'}`}>{day.title}</p>
                                            {video && <p className="text-sm text-slate-500">Video: {video.title}</p>}
                                        </div>
                                        {video && 
                                            <button onClick={() => alert('Video player will be implemented here.')} className="bg-white text-slate-600 hover:bg-emerald-100 hover:text-emerald-700 p-2 rounded-full shadow-sm border border-slate-200 transition">
                                                <PlayIcon className="w-5 h-5"/>
                                            </button>
                                        }
                                    </li>
                                )
                            })}
                         </ul>
                    </div>
                    {/* Right side: Progress */}
                    <div className="md:col-span-1">
                        <div className="bg-white p-6 rounded-lg shadow-md sticky top-24">
                            <h3 className="text-xl font-bold text-slate-800">Your Progress</h3>
                            <div className="mt-4">
                                <div className="flex justify-between mb-1">
                                    <span className="text-sm font-medium text-slate-700">Completion</span>
                                    <span className="text-sm font-medium text-slate-700">{Math.round(progress)}%</span>
                                </div>
                                <div className="w-full bg-slate-200 rounded-full h-3">
                                    <div className="bg-emerald-500 h-3 rounded-full" style={{ width: `${progress}%` }}></div>
                                </div>
                            </div>
                             <div className="mt-4 text-center">
                                <p className="text-3xl font-bold text-emerald-600">{completedDays} <span className="text-xl text-slate-500">/ {challenge.durationDays} Days</span></p>
                                <p className="text-sm text-slate-500">Completed</p>
                            </div>
                            <button onClick={() => alert('Sharing functionality is not yet implemented.')} className="w-full mt-6 bg-emerald-600 text-white px-4 py-3 rounded-lg font-semibold hover:bg-emerald-700 transition">
                                Share My Progress
                            </button>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    );
};

export default ChallengeDetail;
