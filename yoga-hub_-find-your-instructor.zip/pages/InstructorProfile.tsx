
import React, { useState, useMemo } from 'react';
import { useParams, Link } from 'react-router-dom';
import { mockInstructors, mockCourses, mockVideos, mockWorkshops, mockBookingSlots } from '../data/mockData';
import NotFound from './NotFound';
import CourseCard from '../components/CourseCard';
import VideoCard from '../components/VideoCard';
import WorkshopCard from '../components/WorkshopCard';
import TwitterIcon from '../components/icons/TwitterIcon';
import InstagramIcon from '../components/icons/InstagramIcon';
import ClockIcon from '../components/ClockIcon';
import { Instructor } from '../types';

const Stat: React.FC<{ value: string | number; label: string }> = ({ value, label }) => (
  <div>
    <p className="text-xl sm:text-2xl font-bold text-slate-800">{value}</p>
    <p className="text-sm text-slate-500">{label}</p>
  </div>
);

type ProfileTab = 'courses' | 'videos' | 'workshops' | 'booking';

const InstructorProfile: React.FC = () => {
  const { instructorId } = useParams();
  const [activeTab, setActiveTab] = useState<ProfileTab>('courses');

  const { instructor, courses, videos, workshops, bookingSlots } = useMemo(() => {
    const id = Number(instructorId);
    const instructorData = mockInstructors.find(i => i.id === id);
    if (!instructorData) {
      return { instructor: null, courses: [], videos: [], workshops: [], bookingSlots: [] };
    }
    const instructorCourses = mockCourses.filter(c => c.instructorId === id);
    const instructorVideos = mockVideos.filter(v => v.instructorId === id);
    const instructorWorkshops = mockWorkshops.filter(w => w.instructorId === id);
    const instructorBookingSlots = mockBookingSlots.filter(b => b.instructorId === id);

    return { 
        instructor: instructorData, 
        courses: instructorCourses, 
        videos: instructorVideos, 
        workshops: instructorWorkshops,
        bookingSlots: instructorBookingSlots 
    };
  }, [instructorId]);

  if (!instructor) {
    return <NotFound />;
  }
  
  const TabButton: React.FC<{ tab: ProfileTab; label: string; count?: number }> = ({ tab, label, count }) => (
    <button
      onClick={() => setActiveTab(tab)}
      className={`px-3 py-2 font-semibold text-sm rounded-md flex items-center gap-2 transition-colors ${
        activeTab === tab 
        ? 'bg-emerald-100 text-emerald-700' 
        : 'text-slate-600 hover:bg-slate-100 hover:text-slate-800'
      }`}
    >
      {label}
      {count !== undefined && <span className={`px-2 py-0.5 rounded-full text-xs ${activeTab === tab ? 'bg-emerald-200 text-emerald-800' : 'bg-slate-200 text-slate-600'}`}>{count}</span>}
    </button>
  );

  return (
    <div className="space-y-8">
      {/* Profile Header */}
      <div className="bg-white p-6 sm:p-8 rounded-lg shadow-md">
        <div className="flex flex-col sm:flex-row items-center sm:items-start gap-6">
          <img src={instructor.avatarUrl} alt={instructor.name} className="w-32 h-32 rounded-full ring-4 ring-white shadow-lg" />
          <div className="flex-1 text-center sm:text-left">
            <h1 className="text-3xl font-bold text-slate-900">{instructor.name}</h1>
            <p className="text-md text-emerald-600 font-semibold mt-1">{instructor.specialties.join(' & ')}</p>
            <p className="text-slate-600 mt-3 max-w-2xl">{instructor.bio}</p>
            <div className="mt-4 flex justify-center sm:justify-start items-center gap-6">
              <Stat value={instructor.followers.toLocaleString()} label="Followers" />
              <Stat value={instructor.students.toLocaleString()} label="Students" />
              <Stat value={courses.length} label="Courses" />
              <Stat value={workshops.length} label="Workshops" />
            </div>
             <div className="mt-4 flex justify-center sm:justify-start items-center gap-4">
                {instructor.socialLinks.instagram && <a href={instructor.socialLinks.instagram} className="text-slate-500 hover:text-slate-800 transition"><InstagramIcon className="w-6 h-6" /></a>}
                {instructor.socialLinks.twitter && <a href={instructor.socialLinks.twitter} className="text-slate-500 hover:text-slate-800 transition"><TwitterIcon className="w-6 h-6" /></a>}
             </div>
          </div>
        </div>
      </div>

      {/* Content Tabs */}
      <div>
        <div className="border-b border-slate-200">
          <nav className="flex space-x-2" aria-label="Tabs">
            <TabButton tab="courses" label="Courses" count={courses.length} />
            <TabButton tab="videos" label="Videos" count={videos.length} />
            <TabButton tab="workshops" label="Workshops" count={workshops.length} />
            <TabButton tab="booking" label="Book 1-on-1" />
          </nav>
        </div>
        
        <div className="mt-6">
          {activeTab === 'courses' && (
            <div className="grid grid-cols-1 gap-y-10 gap-x-6 sm:grid-cols-2 lg:grid-cols-3 xl:gap-x-8">
              {courses.map(course => <CourseCard key={course.id} course={course} instructor={instructor as Instructor} />)}
            </div>
          )}
          {activeTab === 'videos' && (
            <div className="grid grid-cols-1 gap-y-10 gap-x-6 sm:grid-cols-2 lg:grid-cols-4 xl:gap-x-8">
               {videos.map(video => <VideoCard key={video.id} video={video} instructor={instructor as Instructor} />)}
            </div>
          )}
          {activeTab === 'workshops' && (
             <div className="grid grid-cols-1 gap-y-10 gap-x-6 sm:grid-cols-2 lg:grid-cols-3 xl:gap-x-8">
               {workshops.map(workshop => <WorkshopCard key={workshop.id} workshop={workshop} instructor={instructor as Instructor} />)}
            </div>
          )}
          {activeTab === 'booking' && (
            <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-bold text-slate-800">Book a Private Session</h3>
                <p className="text-slate-500 mt-1">Select an available time slot for a 60-minute one-on-one session.</p>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4 mt-6">
                    {bookingSlots.map(slot => (
                        <button key={slot.id} disabled={slot.isBooked} className={`p-3 rounded-lg text-center font-semibold transition ${slot.isBooked ? 'bg-slate-100 text-slate-400 cursor-not-allowed' : 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100 hover:ring-2 hover:ring-emerald-300'}`}>
                            <p>{slot.startTime.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' })}</p>
                            <p className="text-lg">{slot.startTime.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true })}</p>
                        </button>
                    ))}
                </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default InstructorProfile;