
import React, { useState, useMemo } from 'react';
import { mockProducts, mockAd } from '../data/mockData';
import ProductCard from '../components/ProductCard';
import Sidebar from '../components/Sidebar';
import AdBanner from '../components/AdBanner';
import { FilterState } from '../types';

const Store: React.FC = () => {
  const [filters, setFilters] = useState<FilterState>({
    category: 'All',
    price: 150,
    rating: 0,
    search: '',
  });

  const categories = useMemo(() => ['All', ...new Set(mockProducts.map(p => p.category))], []);

  const filteredProducts = useMemo(() => {
    return mockProducts.filter(product => {
      const categoryMatch = filters.category === 'All' || product.category === filters.category;
      const priceMatch = product.price <= filters.price;
      const ratingMatch = filters.rating === 0 || product.rating >= filters.rating;
      const searchMatch = product.name.toLowerCase().includes(filters.search.toLowerCase()) || product.description.toLowerCase().includes(filters.search.toLowerCase());
      return categoryMatch && priceMatch && ratingMatch && searchMatch;
    });
  }, [filters]);

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFilters(prev => ({ ...prev, search: e.target.value }));
  }

  return (
    <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
        <div className="text-center mb-8">
            <h1 className="text-4xl font-extrabold tracking-tight text-slate-900 sm:text-5xl">Store Marketplace</h1>
            <p className="mt-4 max-w-2xl mx-auto text-xl text-slate-600">Discover curated yoga accessories to elevate your practice.</p>
        </div>

        <AdBanner ad={mockAd} />
      
        <div className="lg:grid lg:grid-cols-4 lg:gap-x-8">
            <Sidebar filters={filters} setFilters={setFilters} categories={categories} />

            <div className="lg:col-span-3">
                <div className="mb-6">
                    <input 
                        type="search" 
                        placeholder="Search products..." 
                        value={filters.search}
                        onChange={handleSearchChange}
                        className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-emerald-500 focus:border-emerald-500"
                    />
                </div>
                <div className="grid grid-cols-1 gap-y-10 gap-x-6 sm:grid-cols-2 lg:grid-cols-3 xl:gap-x-8">
                    {filteredProducts.map(product => (
                    <ProductCard key={product.id} product={product} />
                    ))}
                </div>
                {filteredProducts.length === 0 && (
                    <div className="text-center py-16">
                        <h3 className="text-2xl font-semibold text-slate-800">No Products Found</h3>
                        <p className="mt-2 text-slate-500">Try adjusting your filters to find what you're looking for.</p>
                    </div>
                )}
            </div>
        </div>
    </div>
  );
};

export default Store;
