
import React, { useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { mockChallenges, mockCourses, mockVideos, mockLiveClasses, mockInstructors, mockAd } from '../data/mockData';
import SparklesIcon from '../components/icons/SparklesIcon';
import UsersIcon from '../components/icons/UsersIcon';
import CourseCard from '../components/CourseCard';
import VideoCard from '../components/VideoCard';
import { Instructor } from '../types';
import LiveClassCard from '../components/LiveClassCard';
import AdBanner from '../components/AdBanner';

const DashboardTab: React.FC<{
  label: string;
  isActive: boolean;
  onClick: () => void;
  icon: React.ReactNode;
}> = ({ label, isActive, onClick, icon }) => (
  <button
    onClick={onClick}
    className={`px-4 py-2 font-semibold text-sm rounded-md flex items-center gap-2 transition-colors ${
      isActive 
      ? 'bg-emerald-100 text-emerald-700' 
      : 'text-slate-600 hover:bg-slate-100 hover:text-slate-800'
    }`}
  >
    {icon}
    {label}
  </button>
);

const Overview: React.FC = () => {
    const activeChallenge = mockChallenges[0];
    const progress = (activeChallenge.dailyContent.filter(d => d.completed).length / activeChallenge.durationDays) * 100;

    return (
        <div className="space-y-6">
            <AdBanner ad={mockAd} />
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="md:col-span-2 bg-white p-6 rounded-lg shadow-md">
                    <h3 className="font-bold text-slate-800">Your Active Challenge</h3>
                    <p className="text-sm text-slate-500 mb-4">Keep up the great work!</p>
                    <div className="flex items-center gap-4">
                        <img src={activeChallenge.imageUrl} alt={activeChallenge.title} className="w-24 h-24 rounded-lg object-cover" />
                        <div className="flex-1">
                            <Link to={`/challenges/${activeChallenge.id}`} className="font-semibold text-lg text-slate-800 hover:text-emerald-600">{activeChallenge.title}</Link>
                            <div className="mt-2">
                                <div className="flex justify-between mb-1">
                                    <span className="text-sm font-medium text-slate-700">Progress</span>
                                    <span className="text-sm font-medium text-slate-700">{Math.round(progress)}%</span>
                                </div>
                                <div className="w-full bg-slate-200 rounded-full h-2.5">
                                    <div className="bg-emerald-500 h-2.5 rounded-full" style={{ width: `${progress}%` }}></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="bg-white p-6 rounded-lg shadow-md">
                    <h3 className="font-bold text-slate-800">Upcoming Sessions</h3>
                     <p className="text-sm text-slate-500 mb-4">Your next 1-on-1 class.</p>
                     <div className="space-y-3">
                        <p className="text-slate-700 font-medium">No upcoming sessions. <Link to="/instructors" className="text-emerald-600 hover:underline">Book one now!</Link></p>
                     </div>
                </div>
            </div>
        </div>
    );
};

const ForYou: React.FC = () => {
    const recommendedContent = useMemo(() => {
        const instructorsMap = new Map(mockInstructors.map(i => [i.id, i]));
        const courses = mockCourses.slice(0, 2).map(c => ({...c, instructor: instructorsMap.get(c.instructorId)})).filter(c => c.instructor);
        const videos = mockVideos.slice(0, 4).map(v => ({...v, instructor: instructorsMap.get(v.instructorId)})).filter(v => v.instructor);
        const live = mockLiveClasses.filter(l => !l.isLive).slice(0,1).map(l => ({...l, instructor: instructorsMap.get(l.instructorId)})).filter(l => l.instructor);
        return { courses, videos, live };
    }, []);

    return (
        <div className="space-y-8">
            <div>
                <h3 className="text-2xl font-bold text-slate-800 mb-4">Recommended Live Class</h3>
                {recommendedContent.live.map(item => (
                    <LiveClassCard key={item.id} liveClass={item} instructor={item.instructor as Instructor} />
                ))}
            </div>
             <div>
                <div className="flex justify-between items-center mb-4">
                    <h3 className="text-2xl font-bold text-slate-800">Recommended Courses</h3>
                    <Link to="/learn" className="text-sm font-semibold text-emerald-600 hover:text-emerald-700 transition-colors">
                        View All &rarr;
                    </Link>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {recommendedContent.courses.map(course => (
                        <CourseCard key={course.id} course={course} instructor={course.instructor as Instructor} />
                    ))}
                </div>
            </div>
            <div>
                <h3 className="text-2xl font-bold text-slate-800 mb-4">Recommended Videos</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                    {recommendedContent.videos.map(video => (
                        <VideoCard key={video.id} video={video} instructor={video.instructor as Instructor} />
                    ))}
                </div>
            </div>
        </div>
    )
};

const Dashboard: React.FC = () => {
    const [activeTab, setActiveTab] = useState<'overview' | 'foryou'>('overview');
  
    return (
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
            <div className="space-y-8">
                <div>
                    <h1 className="text-3xl font-bold text-slate-900">Welcome to your Yoga Hub!</h1>
                    <p className="mt-2 text-lg text-slate-600">Your personalized command center for your yoga journey.</p>
                </div>

                <div className="border-b border-slate-200">
                    <nav className="flex space-x-2" aria-label="Tabs">
                        <DashboardTab label="Overview" isActive={activeTab === 'overview'} onClick={() => setActiveTab('overview')} icon={<UsersIcon className="h-5 w-5" />} />
                        <DashboardTab label="For You" isActive={activeTab === 'foryou'} onClick={() => setActiveTab('foryou')} icon={<SparklesIcon className="h-5 w-5" />} />
                    </nav>
                </div>

                <div>
                    {activeTab === 'overview' && <Overview />}
                    {activeTab === 'foryou' && <ForYou />}
                </div>
            </div>
        </div>
    );
};

export default Dashboard;
