
import React, { useMemo } from 'react';
import { Link } from 'react-router-dom';
import { mockLiveClasses, mockInstructors } from '../data/mockData';
import LiveClassCard from '../components/LiveClassCard';
import { Instructor, LiveClass } from '../types';

const ScheduleSection: React.FC<{ title: string; classes: { liveClass: LiveClass; instructor: Instructor }[] }> = ({ title, classes }) => {
    if (classes.length === 0) return null;
    return (
        <div>
            <h2 className="text-2xl font-bold text-slate-800 mb-4">{title}</h2>
            <div className="space-y-4">
                {classes.map(({ liveClass, instructor }) => (
                    <LiveClassCard key={liveClass.id} liveClass={liveClass} instructor={instructor} />
                ))}
            </div>
        </div>
    )
};


const Live: React.FC = () => {
    const { morningClasses, afternoonClasses, eveningClasses } = useMemo(() => {
        const withInstructors = mockLiveClasses.map(liveClass => {
            const instructor = mockInstructors.find(i => i.id === liveClass.instructorId);
            return { liveClass, instructor: instructor! };
        }).filter(item => item.instructor);

        const morning = withInstructors.filter(item => item.liveClass.startTime.getHours() < 12);
        const afternoon = withInstructors.filter(item => item.liveClass.startTime.getHours() >= 12 && item.liveClass.startTime.getHours() < 18);
        const evening = withInstructors.filter(item => item.liveClass.startTime.getHours() >= 18);
        
        return { morningClasses: morning, afternoonClasses: afternoon, eveningClasses: evening };
    }, []);

  return (
    <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
      <div className="space-y-12">
        <div className="text-center">
          <h1 className="text-4xl font-extrabold tracking-tight text-slate-900 sm:text-5xl">Daily Live Classes</h1>
          <p className="mt-4 max-w-2xl mx-auto text-xl text-slate-600">
            Join our world-class instructors for live, interactive yoga sessions. A new schedule every day!
          </p>
        </div>

        <div className="bg-emerald-50 border-l-4 border-emerald-500 text-emerald-800 p-4 rounded-r-lg">
          <p className="font-bold">Unlock Your Potential!</p>
          <p>
              Access all live classes, our full on-demand library, and more with a Yoga Hub membership. 
              <Link to="/subscribe" className="font-bold underline hover:text-emerald-600"> Subscribe Now!</Link>
          </p>
        </div>

        <div className="space-y-8">
          <ScheduleSection title="Morning Sessions" classes={morningClasses} />
          <ScheduleSection title="Afternoon Sessions" classes={afternoonClasses} />
          <ScheduleSection title="Evening Sessions" classes={eveningClasses} />
        </div>
      </div>
    </div>
  );
};

export default Live;
