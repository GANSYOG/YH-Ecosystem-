
import React, { useState, useMemo } from 'react';
import { useLocation } from 'react-router-dom';
import { mockInstructors, mockAd } from '../data/mockData';
import InstructorCard from '../components/InstructorCard';
import Filters from '../components/Filters';
import { SessionType } from '../types';
import AdBanner from '../components/AdBanner';

interface FilterState {
    language: string;
    specialty: string;
    sessionType: string;
    search: string;
}

interface FilterOptions {
    languages: string[];
    specialties: string[];
    sessionTypes: (SessionType | 'All')[];
}

const InstructorDirectory: React.FC = () => {
    const location = useLocation();
    const queryParams = new URLSearchParams(location.search);
    const initialSearch = queryParams.get('q') || '';

    const [filters, setFilters] = useState<FilterState>({
        language: 'All',
        specialty: 'All',
        sessionType: 'All',
        search: initialSearch,
    });

    const { languages, specialties, sessionTypes } = useMemo((): FilterOptions => {
        const langSet = new Set<string>();
        const specSet = new Set<string>();
        const sessSet = new Set<SessionType>();

        mockInstructors.forEach(i => {
            i.languages.forEach(l => langSet.add(l));
            i.specialties.forEach(s => specSet.add(s));
            i.sessionTypes.forEach(st => sessSet.add(st));
        });

        return {
            languages: ['All', ...Array.from(langSet)],
            specialties: ['All', ...Array.from(specSet)],
            sessionTypes: ['All', ...Array.from(sessSet)],
        }
    }, []);

    const filteredInstructors = useMemo(() => {
        return mockInstructors.filter(instructor => {
            const searchMatch = filters.search === '' ||
                instructor.name.toLowerCase().includes(filters.search.toLowerCase()) ||
                instructor.specialties.some(s => s.toLowerCase().includes(filters.search.toLowerCase()));
            
            const languageMatch = filters.language === 'All' || instructor.languages.includes(filters.language);
            const specialtyMatch = filters.specialty === 'All' || instructor.specialties.includes(filters.specialty);
            const sessionTypeMatch = filters.sessionType === 'All' || instructor.sessionTypes.includes(filters.sessionType as SessionType);
            
            return searchMatch && languageMatch && specialtyMatch && sessionTypeMatch;
        });
    }, [filters]);

    return (
        <div className="bg-white">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
                <div className="text-center mb-12">
                    <h1 className="text-4xl font-extrabold tracking-tight text-slate-900 sm:text-5xl">Meet Our Instructors</h1>
                    <p className="mt-4 max-w-2xl mx-auto text-xl text-slate-600">Use the filters to find the perfect guide for your yoga practice.</p>
                </div>
                
                <AdBanner ad={mockAd} />

                <div className="lg:grid lg:grid-cols-4 lg:gap-x-8 mt-8">
                    <Filters 
                        filters={filters} 
                        setFilters={setFilters}
                        languages={languages}
                        specialties={specialties}
                        sessionTypes={sessionTypes}
                    />

                    <div className="lg:col-span-3">
                        <div className="mb-6">
                            <input 
                                type="search" 
                                placeholder="Search by name or specialty..." 
                                value={filters.search}
                                onChange={(e) => setFilters(prev => ({...prev, search: e.target.value}))}
                                className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-emerald-500 focus:border-emerald-500"
                            />
                        </div>
                        <div className="grid grid-cols-1 gap-y-10 gap-x-6 sm:grid-cols-2 xl:grid-cols-3 xl:gap-x-8">
                            {filteredInstructors.map(instructor => (
                                <InstructorCard key={instructor.id} instructor={instructor} />
                            ))}
                        </div>
                        {filteredInstructors.length === 0 && (
                            <div className="text-center py-16">
                                <h3 className="text-2xl font-semibold text-slate-800">No Instructors Found</h3>
                                <p className="mt-2 text-slate-500">Try adjusting your search or filters.</p>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default InstructorDirectory;
