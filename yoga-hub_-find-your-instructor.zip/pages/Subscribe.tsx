import React, { useState, useMemo } from 'react';
import { mockSubscriptionPlans } from '../data/mockData';
import SubscriptionCard from '../components/SubscriptionCard';

type PlanType = 'unlimited' | 'pack';

const TabButton: React.FC<{
  label: string;
  type: PlanType;
  activeType: PlanType;
  onClick: (type: PlanType) => void;
}> = ({ label, type, activeType, onClick }) => (
  <button
    onClick={() => onClick(type)}
    className={`px-4 py-2 font-semibold text-sm rounded-md transition-colors ${
      activeType === type
        ? 'bg-emerald-600 text-white shadow'
        : 'text-slate-600 hover:bg-slate-100'
    }`}
  >
    {label}
  </button>
);


const Subscribe: React.FC = () => {
  const [activeTab, setActiveTab] = useState<PlanType>('unlimited');

  const { unlimitedPlans, packPlans } = useMemo(() => {
    const unlimited = mockSubscriptionPlans.filter(p => p.type === 'unlimited');
    const packs = mockSubscriptionPlans.filter(p => p.type === 'pack');
    return { unlimitedPlans: unlimited, packPlans: packs };
  }, []);
  
  const displayedPlans = activeTab === 'unlimited' ? unlimitedPlans : packPlans;

  return (
    <div className="bg-slate-50 py-12">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="mx-auto max-w-4xl text-center">
          <h2 className="text-base font-semibold leading-7 text-emerald-600">Pricing</h2>
          <p className="mt-2 text-4xl font-bold tracking-tight text-slate-900 sm:text-5xl">
            The perfect plan for your yoga journey
          </p>
        </div>
        <p className="mx-auto mt-6 max-w-2xl text-center text-lg leading-8 text-slate-600">
          Choose from unlimited access memberships or flexible class packs. All plans unlock our world-class content and community.
        </p>
        
        <div className="flex justify-center my-10">
          <div className="bg-slate-200 p-1 rounded-lg flex space-x-1">
            <TabButton label="Unlimited Plans" type="unlimited" activeType={activeTab} onClick={setActiveTab} />
            <TabButton label="Flexible Packs" type="pack" activeType={activeTab} onClick={setActiveTab} />
          </div>
        </div>

        <div className="isolate mx-auto grid max-w-md grid-cols-1 gap-8 sm:mt-20 lg:mx-0 lg:max-w-none lg:grid-cols-3">
          {displayedPlans
            .sort((a, b) => (a.isPopular ? -1 : 1)) // Make sure popular is in middle on large screens
            .map((plan) => (
              <SubscriptionCard key={plan.id} plan={plan} />
            ))}
        </div>
      </div>
    </div>
  );
};

export default Subscribe;