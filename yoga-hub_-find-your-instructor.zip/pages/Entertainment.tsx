import React, { useState, useMemo } from 'react';
import { mockVideos, mockInstructors } from '../data/mockData';
import VideoCard from '../components/VideoCard';
import UploadIcon from '../components/icons/UploadIcon';
import { Video, Instructor } from '../types';

type VideoType = 'reel' | 'short-video';

const Entertainment: React.FC = () => {
  const [activeTab, setActiveTab] = useState<VideoType>('reel');

  const videosWithInstructors = useMemo(() => {
    return mockVideos
      .filter(video => video.type === activeTab)
      .map(video => {
        const instructor = mockInstructors.find(i => i.id === video.instructorId);
        return { video, instructor };
      })
      .filter(item => item.instructor);
  }, [activeTab]);

  const TabButton: React.FC<{ type: VideoType; label: string }> = ({ type, label }) => (
    <button
      onClick={() => setActiveTab(type)}
      className={`px-4 py-2 text-sm font-semibold rounded-md transition-colors ${
        activeTab === type
          ? 'bg-emerald-600 text-white'
          : 'bg-slate-200 text-slate-700 hover:bg-slate-300'
      }`}
    >
      {label}
    </button>
  );

  return (
    <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
      <div className="space-y-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
              <h1 className="text-4xl font-extrabold tracking-tight text-slate-900 sm:text-5xl">Videos & Shorts</h1>
              <p className="mt-3 max-w-2xl text-lg text-slate-600">
              Discover inspiring shorts and videos from our talented instructors.
              </p>
          </div>
          <button className="flex-shrink-0 bg-emerald-600 text-white px-4 py-2 rounded-md font-semibold hover:bg-emerald-700 transition-transform duration-200 hover:scale-105 flex items-center gap-2">
              <UploadIcon className="w-5 h-5" />
              <span>Upload Video</span>
          </button>
        </div>
        
        <div className="border-b border-slate-200">
          <nav className="flex space-x-2" aria-label="Tabs">
              <TabButton type="reel" label="Shorts" />
              <TabButton type="short-video" label="Videos" />
          </nav>
        </div>

        <div>
          <div className="grid grid-cols-1 gap-y-10 gap-x-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 xl:gap-x-8">
            {videosWithInstructors.map(({ video, instructor }) => (
              <VideoCard key={video.id} video={video} instructor={instructor as Instructor} />
            ))}
          </div>
          {videosWithInstructors.length === 0 && (
            <div className="text-center py-16">
              <h3 className="text-2xl font-semibold text-slate-800">No Videos Yet</h3>
              <p className="mt-2 text-slate-500">Check back later for new content or be the first to upload!</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Entertainment;