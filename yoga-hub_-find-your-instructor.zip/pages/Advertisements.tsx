
import React from 'react';
import { Link } from 'react-router-dom';
import { mockAdCampaigns } from '../data/mockData';
import AdCampaignCard from '../components/AdCampaignCard';
import SparklesIcon from '../components/icons/SparklesIcon';

const Advertisements: React.FC = () => {
  return (
    <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
      <div className="space-y-12">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
            <div>
                 <h1 className="text-4xl font-extrabold tracking-tight text-slate-900 sm:text-5xl">Advertising Dashboard</h1>
                <p className="mt-4 max-w-2xl text-xl text-slate-600">
                    Reach a targeted audience of yoga enthusiasts. Manage your campaigns and track performance.
                </p>
            </div>
            <Link to="/advertise/new" className="flex-shrink-0 bg-emerald-600 text-white px-6 py-3 rounded-md font-semibold hover:bg-emerald-700 transition-transform duration-200 hover:scale-105 flex items-center gap-2 shadow-lg">
                <SparklesIcon className="w-5 h-5" />
                <span>Create New Campaign</span>
            </Link>
        </div>
        
        <div className="space-y-8">
            <h2 className="text-2xl font-bold text-slate-800">Your Campaigns</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {mockAdCampaigns.map(campaign => (
                    <AdCampaignCard key={campaign.id} campaign={campaign} />
                ))}
            </div>
             {mockAdCampaigns.length === 0 && (
                <div className="text-center py-16 bg-white rounded-lg shadow-md">
                    <h3 className="text-2xl font-semibold text-slate-800">No Campaigns Yet</h3>
                    <p className="mt-2 text-slate-500">Start by creating your first ad campaign to reach new students.</p>
                </div>
            )}
        </div>
      </div>
    </div>
  );
};

export default Advertisements;
