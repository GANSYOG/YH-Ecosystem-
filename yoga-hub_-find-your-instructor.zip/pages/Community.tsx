
import React, { useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { mockChallenges, mockForumCategories, mockInstructors } from '../data/mockData';
import ChallengeCard from '../components/ChallengeCard';
import { Instructor, Challenge, ForumCategory } from '../types';
import ClipboardCheckIcon from '../components/icons/ClipboardCheckIcon';
import BookOpenIcon from '../components/icons/BookOpenIcon';

type CommunityTab = 'challenges' | 'forums';

const TabButton: React.FC<{ tab: CommunityTab; label: string; isActive: boolean; onClick: () => void; icon: React.ReactNode; }> = ({ tab, label, isActive, onClick, icon }) => (
    <button
      onClick={onClick}
      className={`px-4 py-3 font-semibold text-sm rounded-t-lg flex items-center gap-2 border-b-2 transition-colors ${
        isActive 
        ? 'border-emerald-500 text-emerald-600' 
        : 'border-transparent text-slate-500 hover:border-slate-300 hover:text-slate-700'
      }`}
    >
      {icon}
      {label}
    </button>
  );

const ChallengesView: React.FC = () => {
    const challengesWithInstructors = useMemo(() => {
        return mockChallenges.map(challenge => ({
            challenge,
            instructor: mockInstructors.find(i => i.id === challenge.instructorId)
        })).filter(item => item.instructor);
    }, []);

    return (
         <div className="grid grid-cols-1 gap-y-10 gap-x-6 sm:grid-cols-2 lg:grid-cols-3 xl:gap-x-8">
            {challengesWithInstructors.map(({ challenge, instructor }) => (
                <ChallengeCard key={challenge.id} challenge={challenge} instructor={instructor as Instructor} />
            ))}
        </div>
    );
};

const ForumsView: React.FC = () => {
    return (
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
            <ul role="list" className="divide-y divide-slate-200">
                {mockForumCategories.map(category => (
                    <li key={category.id} className="p-4 hover:bg-slate-50 transition-colors">
                        <div className="flex items-center gap-4">
                            <div className="bg-emerald-100 p-3 rounded-lg">
                                <BookOpenIcon className="h-6 w-6 text-emerald-600" />
                            </div>
                            <div className="flex-1">
                                <Link to={`/community/forum/${category.id}`} className="font-semibold text-slate-800 hover:text-emerald-600">{category.name}</Link>
                                <p className="text-sm text-slate-500">{category.description}</p>
                            </div>
                            <div className="text-center w-24 hidden sm:block">
                                <p className="font-semibold text-slate-700">{category.threadCount}</p>
                                <p className="text-xs text-slate-500">Threads</p>
                            </div>
                            <div className="text-center w-24 hidden sm:block">
                                <p className="font-semibold text-slate-700">{category.postCount}</p>
                                <p className="text-xs text-slate-500">Posts</p>
                            </div>
                        </div>
                    </li>
                ))}
            </ul>
        </div>
    );
}

const Community: React.FC = () => {
  const [activeTab, setActiveTab] = useState<CommunityTab>('challenges');

  return (
    <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
      <div className="space-y-8">
        <div className="text-center">
          <h1 className="text-4xl font-extrabold tracking-tight text-slate-900 sm:text-5xl">Community Hub</h1>
          <p className="mt-4 max-w-2xl mx-auto text-xl text-slate-600">
            Connect with others, join a challenge, and grow together.
          </p>
        </div>
        
        <div>
          <div className="border-b border-slate-200">
              <nav className="-mb-px flex space-x-4" aria-label="Tabs">
                  <TabButton tab="challenges" label="Challenges" isActive={activeTab === 'challenges'} onClick={() => setActiveTab('challenges')} icon={<ClipboardCheckIcon className="w-5 h-5"/>} />
                  <TabButton tab="forums" label="Forums" isActive={activeTab === 'forums'} onClick={() => setActiveTab('forums')} icon={<BookOpenIcon className="w-5 h-5"/>} />
              </nav>
          </div>
          <div className="mt-6">
              {activeTab === 'challenges' && <ChallengesView />}
              {activeTab === 'forums' && <ForumsView />}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Community;
