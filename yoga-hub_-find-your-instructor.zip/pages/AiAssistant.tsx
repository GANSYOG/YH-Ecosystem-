
import React, { useState } from 'react';
import { GoogleGenAI } from '@google/genai';
import SparklesIcon from '../components/icons/SparklesIcon';
import { Link } from 'react-router-dom';

const AiAssistant: React.FC = () => {
  const [prompt, setPrompt] = useState('');
  const [response, setResponse] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt) {
      setError('Please enter a description for your program.');
      return;
    }
    setError('');
    setResponse('');
    setIsLoading(true);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
      const fullPrompt = `
        You are an expert yoga curriculum designer. Create a detailed yoga program based on the following goal: "${prompt}".
        Provide a theme for each week if it's a multi-week program. For each day or session, suggest a class title, key poses to focus on, and a short description or talking point.
        Format the output as clean, readable markdown. Use headings, lists, and bold text to structure the content.
      `;
      const genAIResponse = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: fullPrompt,
      });

      setResponse(genAIResponse.text);

    } catch (err) {
      console.error(err);
      setError('An error occurred while generating the content. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
      <div className="space-y-8">
        <div className="text-center">
          <div className="inline-flex items-center justify-center bg-emerald-100 rounded-full p-3">
            <SparklesIcon className="w-8 h-8 text-emerald-600" />
          </div>
          <h1 className="mt-4 text-4xl font-extrabold tracking-tight text-slate-900 sm:text-5xl">AI Content Creation Suite</h1>
          <p className="mt-4 max-w-2xl mx-auto text-xl text-slate-600">
            Describe your program goal and let our AI assistant draft a structured curriculum for you.
          </p>
        </div>

        <div className="max-w-3xl mx-auto">
          <form onSubmit={handleSubmit} className="bg-white p-6 rounded-lg shadow-md space-y-4">
            <div>
              <label htmlFor="prompt" className="block text-sm font-bold text-gray-700 mb-2">
                Describe your desired yoga program
              </label>
              <textarea
                id="prompt"
                rows={4}
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-emerald-500 focus:border-emerald-500"
                placeholder="e.g., A 4-week beginner program focused on improving flexibility and reducing stress."
              />
            </div>
            <button
              type="submit"
              disabled={isLoading}
              className="w-full flex justify-center items-center gap-2 rounded-md border border-transparent bg-emerald-600 py-3 px-4 text-base font-medium text-white shadow-sm hover:bg-emerald-700 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:ring-offset-2 disabled:bg-slate-400"
            >
              {isLoading ? (
                <>
                  <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  Generating...
                </>
              ) : 'Generate Content'}
            </button>
            {error && <p className="text-sm text-red-600">{error}</p>}
          </form>

          {response && (
            <div className="mt-8 bg-white p-6 rounded-lg shadow-md">
                <h2 className="text-2xl font-bold text-slate-800 mb-4">Your Generated Plan:</h2>
                <pre className="whitespace-pre-wrap font-sans text-slate-800 bg-slate-50 p-4 rounded-md text-sm leading-relaxed" aria-live="polite">
                    {response}
                </pre>
            </div>
          )}
        </div>
         <div className="text-center text-slate-500 text-sm mt-8">
              <p>AI can make mistakes. Consider checking important information.</p>
              <p>Not an instructor? <Link to="/for-instructors" className="text-emerald-600 hover:underline">Learn more about joining Yoga Hub.</Link></p>
          </div>
      </div>
    </div>
  );
};

export default AiAssistant;
