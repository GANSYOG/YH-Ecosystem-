
import React, { useState, useMemo } from 'react';
import { mockCourses, mockInstructors, mockAd } from '../data/mockData';
import CourseCard from '../components/CourseCard';
import AdBanner from '../components/AdBanner';
import { Course, Instructor } from '../types';

const Learn: React.FC = () => {
  const [language, setLanguage] = useState('All');

  const { coursesWithInstructors, availableLanguages } = useMemo(() => {
    const langSet = new Set<string>(['All']);
    mockCourses.forEach(c => langSet.add(c.language));

    const allCourses = mockCourses.map(course => {
      const instructor = mockInstructors.find(i => i.id === course.instructorId);
      return { course, instructor };
    }).filter(item => item.instructor);

    const filtered = language === 'All'
      ? allCourses
      : allCourses.filter(({ course }) => course.language === language);
    
    return {
        coursesWithInstructors: filtered,
        availableLanguages: Array.from(langSet)
    }
  }, [language]);

  return (
    <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
      <div className="space-y-12">
        <div className="text-center">
          <h1 className="text-4xl font-extrabold tracking-tight text-slate-900 sm:text-5xl">Learning Hub</h1>
          <p className="mt-4 max-w-2xl mx-auto text-xl text-slate-600">
            Deepen your practice at your own pace with our library of courses from world-class instructors, available in multiple languages.
          </p>
        </div>
        
        <AdBanner ad={mockAd} />

        <div className="flex justify-between items-center flex-wrap gap-4">
          <h2 className="text-2xl font-bold text-slate-800">All Courses</h2>
          <div className="flex items-center gap-2">
            <label htmlFor="language-filter" className="text-sm font-medium text-slate-700">Language:</label>
            <select
                id="language-filter"
                value={language}
                onChange={(e) => setLanguage(e.target.value)}
                className="bg-slate-100 border-slate-200 rounded-md p-2 text-sm font-medium text-slate-700 focus:ring-emerald-500 focus:border-emerald-500"
            >
                {availableLanguages.map(lang => <option key={lang} value={lang}>{lang}</option>)}
            </select>
          </div>
        </div>

        <div>
          {coursesWithInstructors.length > 0 ? (
            <div className="grid grid-cols-1 gap-y-10 gap-x-6 sm:grid-cols-2 lg:grid-cols-3 xl:gap-x-8">
              {coursesWithInstructors.map(({ course, instructor }) => (
                <CourseCard key={course.id} course={course} instructor={instructor as Instructor} />
              ))}
            </div>
          ) : (
             <div className="text-center py-16">
                <h3 className="text-2xl font-semibold text-slate-800">No Courses Found</h3>
                <p className="mt-2 text-slate-500">There are no courses available in the selected language. Try another one!</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Learn;
