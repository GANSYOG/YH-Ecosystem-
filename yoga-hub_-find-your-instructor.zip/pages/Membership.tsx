
import React from 'react';
import { mockStudentPlans } from '../data/mockData';
import PricingCard from '../components/PricingCard';

const Membership: React.FC = () => {
  return (
    <div className="bg-white py-12 sm:py-16">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
           <h2 className="text-base font-semibold leading-7 text-emerald-600">Membership</h2>
          <h1 className="text-4xl font-extrabold tracking-tight text-slate-900 sm:text-5xl">The Perfect Plan for Your Journey</h1>
          <p className="mt-6 text-xl text-slate-600">
            Choose a membership to unlock class credits, book sessions with any instructor, and get the most out of the Yoga Hub platform.
          </p>
        </div>

        <div className="mt-16">
             <div className="isolate mx-auto grid max-w-md grid-cols-1 gap-8 lg:mx-0 lg:max-w-none lg:grid-cols-3">
                {mockStudentPlans
                    .sort((a,b) => (a.isPopular === b.isPopular)? 0 : a.isPopular? -1 : 1)
                    .map(plan => (
                        <PricingCard 
                            key={plan.id}
                            plan={{...plan, ctaText: "Choose Plan"}}
                            checkoutUrl={`/checkout/${plan.id}`}
                        />
                ))}
            </div>
        </div>
      </div>
    </div>
  );
};

export default Membership;
