
import React from 'react';
import { Link } from 'react-router-dom';
import { mockInstructorPlans } from '../data/mockData';
import PricingCard from '../components/PricingCard';
import CheckIcon from '../components/icons/CheckIcon';
import SparklesIcon from '../components/icons/SparklesIcon';
import ChartBarIcon from '../components/icons/ChartBarIcon';

const Feature: React.FC<{ icon: React.ReactNode, title: string, description: string }> = ({ icon, title, description }) => (
  <div className="flex items-start gap-4">
    <div className="flex-shrink-0 h-12 w-12 flex items-center justify-center rounded-lg bg-emerald-100 text-emerald-600">
      {icon}
    </div>
    <div>
      <h3 className="text-lg font-bold text-slate-800">{title}</h3>
      <p className="mt-1 text-slate-600">{description}</p>
    </div>
  </div>
);


const ForInstructors: React.FC = () => {
  return (
    <div className="bg-slate-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-4xl font-extrabold tracking-tight text-slate-900 sm:text-5xl">Grow Your Yoga Business</h1>
          <p className="mt-6 text-xl text-slate-600">
            Join Yoga Hub to connect with students from around the world, manage your schedule, and build your brand on a platform designed for yoga professionals.
          </p>
        </div>
        
        <div className="mt-16 bg-white p-8 rounded-2xl shadow-lg">
           <h2 className="text-3xl font-bold tracking-tight text-slate-900 text-center mb-12">Powerful Tools for Your Success</h2>
           <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-10">
              <Feature icon={<SparklesIcon className="w-6 h-6" />} title="AI Content Creation Suite" description="Overcome creative blocks. Describe your course goal, and our AI assistant will generate a structured plan with themes, talking points, and more." />
              <Feature icon={<ChartBarIcon className="w-6 h-6" />} title="Business Insights" description="Make data-driven decisions with a private dashboard tracking your revenue, student growth, and most popular content." />
              <Feature icon={<CheckIcon className="w-6 h-6" />} title="Multiple Revenue Streams" description="Monetize more than just classes. Sell workshops, courses, videos, and even products through your integrated store." />
              <Feature icon={<CheckIcon className="w-6 h-6" />} title="Simple Scheduling" description="Manage your 1-on-1 bookings and group class schedule with our easy-to-use tools." />
           </div>
            <div className="mt-12 text-center">
                <Link to="/ai-assistant" className="bg-emerald-600 text-white px-6 py-3 rounded-md font-semibold hover:bg-emerald-700 transition-transform duration-200 hover:scale-105">
                    Explore AI Tools
                </Link>
            </div>
        </div>

        <div className="mt-16">
            <h2 className="text-3xl font-bold tracking-tight text-slate-900 text-center">Join the Platform</h2>
             <p className="mt-4 text-lg text-slate-600 text-center max-w-2xl mx-auto">
              Simple, transparent pricing to get you started.
            </p>
            <div className="isolate mx-auto mt-10 grid max-w-md grid-cols-1 gap-8 lg:mx-0 lg:max-w-2xl lg:grid-cols-2">
                {mockInstructorPlans.map(plan => (
                    <PricingCard 
                        key={plan.id}
                        plan={{...plan, ctaText: "Get Started"}}
                        checkoutUrl={`/checkout/instructor/${plan.id}`}
                    />
                ))}
            </div>
        </div>
      </div>
    </div>
  );
};

export default ForInstructors;
