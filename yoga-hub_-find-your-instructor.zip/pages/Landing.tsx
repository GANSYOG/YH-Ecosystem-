
import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { mockInstructors } from '../data/mockData';
import InstructorCard from '../components/InstructorCard';

const Landing: React.FC = () => {
    const navigate = useNavigate();

    const handleSearch = (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        const formData = new FormData(e.currentTarget);
        const query = formData.get('search_query') as string;
        navigate(`/instructors?q=${query}`);
    }

    return (
        <div className="bg-slate-50">
            {/* Hero Section */}
            <div className="relative">
                <div className="absolute inset-0">
                    <img className="w-full h-full object-cover" src="https://picsum.photos/seed/yogahome/1920/1080" alt="Woman doing yoga" />
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-900/50 to-emerald-900/30"></div>
                </div>
                <div className="relative container mx-auto px-4 sm:px-6 lg:px-8 py-24 sm:py-32 text-center text-white">
                    <h1 className="text-4xl sm:text-5xl md:text-6xl font-extrabold tracking-tight">
                        Find Your Perfect Yoga Instructor
                    </h1>
                    <p className="mt-6 max-w-2xl mx-auto text-lg sm:text-xl text-slate-200">
                        Any language, any style, anywhere. Connect with certified yoga teachers from across India and the world.
                    </p>
                    <form onSubmit={handleSearch} className="mt-8 max-w-xl mx-auto flex items-center bg-white rounded-full shadow-lg p-2">
                        <input
                            type="search"
                            name="search_query"
                            placeholder="Search by specialty, language, or name..."
                            className="w-full bg-transparent text-slate-700 px-4 py-2 border-none focus:ring-0"
                        />
                        <button type="submit" className="bg-emerald-600 text-white px-6 py-2 rounded-full font-semibold hover:bg-emerald-700 transition">
                            Search
                        </button>
                    </form>
                </div>
            </div>

            {/* Featured Instructors */}
            <div className="bg-white py-16 sm:py-24">
                <div className="container mx-auto px-4 sm:px-6 lg:px-8">
                    <h2 className="text-3xl font-bold tracking-tight text-slate-900 text-center">Featured Instructors</h2>
                    <p className="mt-4 text-lg text-slate-600 text-center max-w-2xl mx-auto">
                        Meet some of our top-rated instructors ready to guide you on your yoga journey.
                    </p>
                    <div className="mt-12 grid grid-cols-1 gap-y-10 gap-x-6 sm:grid-cols-2 lg:grid-cols-3 xl:gap-x-8">
                        {mockInstructors.slice(0, 3).map(instructor => (
                            <InstructorCard key={instructor.id} instructor={instructor} />
                        ))}
                    </div>
                     <div className="mt-12 text-center">
                        <Link to="/instructors" className="text-lg font-semibold text-emerald-600 hover:text-emerald-700">
                            Explore all instructors &rarr;
                        </Link>
                    </div>
                </div>
            </div>
            
            {/* For Instructors CTA */}
            <div className="bg-emerald-700">
                <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-20 text-center">
                    <h2 className="text-3xl font-bold tracking-tight text-white">
                        Are you a Yoga Instructor?
                    </h2>
                    <p className="mt-4 text-lg text-emerald-200 max-w-2xl mx-auto">
                        Join our platform to grow your business, reach a global audience, and manage your classes with ease.
                    </p>
                    <div className="mt-8">
                        <Link
                            to="/for-instructors"
                            className="inline-block bg-white text-emerald-700 px-8 py-3 rounded-md text-base font-semibold hover:bg-emerald-50 transition-transform duration-200 hover:scale-105"
                        >
                           Start Teaching Today
                        </Link>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Landing;
