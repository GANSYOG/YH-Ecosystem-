
import React, { useMemo } from 'react';
import { useParams, Link } from 'react-router-dom';
import { mockProducts, mockAd } from '../data/mockData';
import NotFound from './NotFound';
import StarIcon from '../components/icons/StarIcon';
import AdBanner from '../components/AdBanner';
import ProductCard from '../components/ProductCard';
import HeartIcon from '../components/icons/HeartIcon';

const ProductDetail: React.FC = () => {
  const { productId } = useParams();

  const { product, relatedProducts } = useMemo(() => {
    const p = mockProducts.find(p => p.id === Number(productId));
    if (!p) return { product: null, relatedProducts: [] };

    const rel = mockProducts.filter(rp => rp.category === p.category && rp.id !== p.id).slice(0, 4);
    return { product: p, relatedProducts: rel };
  }, [productId]);

  if (!product) {
    return <NotFound />;
  }

  return (
    <div className="bg-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
            <div className="lg:grid lg:grid-cols-2 lg:gap-x-12 lg:items-start">
                {/* Image gallery */}
                <div className="w-full aspect-w-1 aspect-h-1">
                    <img src={product.imageUrl} alt={product.name} className="w-full h-full object-cover rounded-lg shadow-lg" />
                </div>

                {/* Product info */}
                <div className="mt-10 sm:px-0 sm:mt-16 lg:mt-0">
                    <p className="text-sm font-medium text-slate-500">{product.category}</p>
                    <h1 className="text-3xl font-extrabold tracking-tight text-slate-900">{product.name}</h1>

                    <div className="mt-3">
                        <h2 className="sr-only">Product information</h2>
                        <div className="flex items-baseline gap-x-2">
                             <span className="text-3xl font-bold text-slate-900">₹{product.price}</span>
                            {product.originalPrice && (
                            <span className="text-lg text-slate-500 line-through">₹{product.originalPrice}</span>
                            )}
                        </div>
                    </div>

                    {/* Reviews */}
                    <div className="mt-4">
                        <h3 className="sr-only">Reviews</h3>
                        <div className="flex items-center">
                            <div className="flex items-center">
                                {[...Array(5)].map((_, i) => (
                                <StarIcon key={i} className={`h-5 w-5 ${i < Math.round(product.rating) ? 'text-amber-400' : 'text-slate-300'}`} aria-hidden="true" />
                                ))}
                            </div>
                            <p className="sr-only">{product.rating} out of 5 stars</p>
                            <a href="#" onClick={(e) => e.preventDefault()} className="ml-3 text-sm font-medium text-emerald-600 hover:text-emerald-500">{product.reviewCount} reviews</a>
                        </div>
                    </div>

                    <div className="mt-6">
                        <h3 className="sr-only">Description</h3>
                        <div className="text-base text-slate-700 space-y-6">
                            <p>{product.description}</p>
                        </div>
                    </div>

                    <form className="mt-6">
                        <div className="mt-10 flex gap-x-4">
                            <button
                                type="button"
                                onClick={() => alert(`Added ${product.name} to cart!`)}
                                className="max-w-xs flex-1 bg-emerald-600 border border-transparent rounded-md py-3 px-8 flex items-center justify-center text-base font-medium text-white hover:bg-emerald-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-50 focus:ring-emerald-500 sm:w-full"
                            >
                                Add to cart
                            </button>
                             <button
                                type="button"
                                onClick={() => alert(`Added ${product.name} to wishlist!`)}
                                className="p-3 text-slate-500 bg-slate-100 rounded-md hover:bg-slate-200 hover:text-emerald-600 transition-colors"
                            >
                                <HeartIcon className="h-6 w-6" />
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            {relatedProducts.length > 0 && (
                <div className="mt-24">
                     <h2 className="text-2xl font-bold text-slate-800 mb-6">You might also like</h2>
                     <div className="grid grid-cols-1 gap-y-10 gap-x-6 sm:grid-cols-2 lg:grid-cols-4 xl:gap-x-8">
                        {relatedProducts.map(p => (
                            <ProductCard key={p.id} product={p} />
                        ))}
                    </div>
                </div>
            )}
            
            <div className="mt-16">
                <AdBanner ad={mockAd} />
            </div>
        </div>
    </div>
  );
};

export default ProductDetail;
